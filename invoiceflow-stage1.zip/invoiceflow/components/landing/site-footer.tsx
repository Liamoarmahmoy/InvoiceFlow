import Link from "next/link";
import { Logo } from "@/components/brand/logo";

export function SiteFooter() {
  return (
    <footer className="no-print border-t border-navy-100 bg-white">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 md:grid-cols-4">
        <div className="md:col-span-2">
          <Logo />
          <p className="mt-4 max-w-sm text-sm text-navy-500">
            Simple, professional invoicing for UK sole traders, freelancers and small businesses.
          </p>
        </div>
        <div>
          <h3 className="text-sm font-bold text-navy-900">Product</h3>
          <ul className="mt-3 space-y-2 text-sm text-navy-500">
            <li><Link className="hover:text-emerald-600" href="/create">Create an invoice</Link></li>
            <li><Link className="hover:text-emerald-600" href="/invoices">My invoices</Link></li>
            <li><Link className="hover:text-emerald-600" href="/#pricing">Pricing</Link></li>
          </ul>
        </div>
        <div>
          <h3 className="text-sm font-bold text-navy-900">Help</h3>
          <ul className="mt-3 space-y-2 text-sm text-navy-500">
            <li><Link className="hover:text-emerald-600" href="/#faq">FAQ</Link></li>
            <li><Link className="hover:text-emerald-600" href="/create?sample=1">Sample invoice</Link></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-navy-100">
        <p className="mx-auto max-w-7xl px-4 py-6 text-xs text-navy-400 sm:px-6">
          © {new Date().getFullYear()} InvoiceFlow. InvoiceFlow is not a substitute for professional accounting or tax advice.
        </p>
      </div>
    </footer>
  );
}
