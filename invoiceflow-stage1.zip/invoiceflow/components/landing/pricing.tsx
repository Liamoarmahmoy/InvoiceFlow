import Link from "next/link";
import { Check, Minus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { PLANS, COMPARISON } from "@/lib/plans";

export function Pricing() {
  return (
    <section id="pricing" className="scroll-mt-20 bg-navy-50/60 py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-bold uppercase tracking-widest text-emerald-600">Pricing</p>
          <h2 className="mt-3 font-display text-3xl font-extrabold tracking-tight text-navy-900 sm:text-4xl">
            Simple pricing. No surprises.
          </h2>
          <p className="mt-4 text-lg text-navy-500">Start free and upgrade only when your business needs more. Prices in GBP, cancel any time.</p>
        </div>

        <div className="mt-14 grid gap-6 lg:grid-cols-3">
          {PLANS.map((plan) => (
            <div
              key={plan.id}
              className={cn(
                "relative flex flex-col rounded-3xl border bg-white p-8 transition duration-300 hover:-translate-y-1 hover:shadow-xl",
                plan.highlight ? "border-emerald-400 shadow-lg shadow-emerald-500/10 ring-1 ring-emerald-400" : "border-navy-100"
              )}
            >
              {plan.highlight && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-emerald-500 px-3 py-1 text-xs font-bold text-navy-950">
                  Most popular
                </span>
              )}
              <h3 className="font-display text-lg font-bold text-navy-900">{plan.name}</h3>
              <p className="mt-1 text-sm text-navy-500">{plan.tagline}</p>
              <p className="mt-6 flex items-baseline gap-1">
                <span className="font-display text-5xl font-extrabold tracking-tight text-navy-900">{plan.priceLabel}</span>
                <span className="text-sm text-navy-500">/month</span>
              </p>
              <ul className="mt-8 flex-1 space-y-3 text-sm">
                {plan.features.map((f) => (
                  <li key={f} className="flex gap-3 text-navy-700">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-emerald-500" aria-hidden />
                    {f}
                  </li>
                ))}
              </ul>
              {plan.id === "free" ? (
                <Button asChild size="lg" className="mt-8 w-full">
                  <Link href="/create">Start Free</Link>
                </Button>
              ) : (
                // Paid checkout arrives in Stage 4 (Stripe). Until then we say so
                // honestly rather than showing a button that does nothing.
                <div className="mt-8 rounded-xl border border-dashed border-navy-200 bg-navy-50 px-4 py-3 text-center text-sm font-semibold text-navy-600">
                  Paid plans launching soon
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="mt-16 overflow-x-auto rounded-2xl border border-navy-100 bg-white">
          <table className="w-full min-w-[560px] text-left text-sm">
            <caption className="sr-only">Plan comparison</caption>
            <thead>
              <tr className="border-b border-navy-100 bg-navy-50/50">
                <th scope="col" className="px-6 py-4 font-semibold text-navy-500">Compare plans</th>
                {PLANS.map((p) => (
                  <th key={p.id} scope="col" className="px-6 py-4 text-center font-display font-bold text-navy-900">
                    {p.name}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {COMPARISON.map((row) => (
                <tr key={row.label} className="border-b border-navy-50 last:border-0">
                  <th scope="row" className="px-6 py-3.5 font-medium text-navy-700">{row.label}</th>
                  {row.values.map((v, i) => (
                    <td key={i} className="px-6 py-3.5 text-center">
                      {v === true ? (
                        <Check className="mx-auto h-5 w-5 text-emerald-500" aria-label="Included" />
                      ) : v === false ? (
                        <Minus className="mx-auto h-5 w-5 text-navy-200" aria-label="Not included" />
                      ) : (
                        <span className="font-medium text-navy-800">{v}</span>
                      )}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
}
