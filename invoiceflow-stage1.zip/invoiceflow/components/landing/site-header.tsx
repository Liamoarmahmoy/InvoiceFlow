"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { Menu, X } from "lucide-react";
import { Logo } from "@/components/brand/logo";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const NAV = [
  { href: "/#features", label: "Features" },
  { href: "/#pricing", label: "Pricing" },
  { href: "/#faq", label: "FAQ" },
  { href: "/invoices", label: "My invoices" },
];

export function SiteHeader({ variant = "dark" }: { variant?: "dark" | "light" }) {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  const dark = variant === "dark" && !scrolled && !open;

  return (
    <header
      className={cn(
        "no-print sticky top-0 z-40 transition-all duration-300",
        dark ? "bg-transparent" : "border-b border-navy-100 bg-white/90 backdrop-blur-lg",
        variant === "dark" && "-mb-[65px]"
      )}
    >
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6">
        <Link href="/" aria-label="InvoiceFlow home" className="rounded-lg focus-visible:outline-2 focus-visible:outline-emerald-500">
          <Logo dark={dark} />
        </Link>
        <nav className="hidden items-center gap-1 md:flex" aria-label="Main">
          {NAV.map((n) => (
            <Link
              key={n.href}
              href={n.href}
              className={cn(
                "rounded-lg px-3 py-2 text-sm font-medium transition",
                dark ? "text-white/75 hover:bg-white/10 hover:text-white" : "text-navy-600 hover:bg-navy-50 hover:text-navy-900"
              )}
            >
              {n.label}
            </Link>
          ))}
        </nav>
        <div className="hidden md:block">
          <Button asChild>
            <Link href="/create">Start Free</Link>
          </Button>
        </div>
        <button
          className={cn("rounded-lg p-2 md:hidden", dark ? "text-white" : "text-navy-900")}
          onClick={() => setOpen((o) => !o)}
          aria-label={open ? "Close menu" : "Open menu"}
          aria-expanded={open}
        >
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>
      {open && (
        <div className="border-t border-navy-100 bg-white px-4 pb-4 md:hidden">
          {NAV.map((n) => (
            <Link key={n.href} href={n.href} onClick={() => setOpen(false)} className="block rounded-lg px-3 py-3 font-medium text-navy-700 hover:bg-navy-50">
              {n.label}
            </Link>
          ))}
          <Button asChild className="mt-2 w-full">
            <Link href="/create">Start Free</Link>
          </Button>
        </div>
      )}
    </header>
  );
}
