"use client";

import { GripVertical, Plus, Trash2 } from "lucide-react";
import type { LineItem } from "@/lib/invoice/types";
import { formatPence } from "@/lib/invoice/format";
import { Button } from "@/components/ui/button";
import { Input, Select } from "@/components/ui/input";
import { VAT_RATE_OPTIONS } from "@/lib/invoice/defaults";
import { cn } from "@/lib/utils";
import type { Errors } from "@/lib/invoice/validation";

interface Props {
  items: LineItem[];
  lineTotals: number[];
  vatEnabled: boolean;
  errors: Errors;
  onChange: (index: number, patch: Partial<LineItem>) => void;
  onAdd: () => void;
  onRemove: (index: number) => void;
}

export function LineItemsEditor({ items, lineTotals, vatEnabled, errors, onChange, onAdd, onRemove }: Props) {
  return (
    <div>
      <div className="hidden grid-cols-[1fr_80px_110px_110px_100px_36px] gap-2 px-1 pb-2 text-xs font-semibold text-navy-500 md:grid">
        <span>Description</span>
        <span className="text-right">Qty</span>
        <span className="text-right">Price (£)</span>
        <span>{vatEnabled ? "VAT rate" : ""}</span>
        <span className="text-right">Amount</span>
        <span />
      </div>
      <ul className="space-y-3 md:space-y-2">
        {items.map((it, i) => {
          const err = (f: string) => errors[`items.${i}.${f}`];
          return (
            <li
              key={it.id}
              className="group relative rounded-xl border border-navy-100 bg-navy-50/40 p-3 transition hover:border-navy-200 md:grid md:grid-cols-[1fr_80px_110px_110px_100px_36px] md:items-start md:gap-2 md:border-0 md:bg-transparent md:p-0"
            >
              <div className="flex items-start gap-1">
                <GripVertical className="mt-3 hidden h-4 w-4 shrink-0 text-navy-200 md:block" aria-hidden />
                <div className="w-full">
                  <label htmlFor={`item-${it.id}-desc`} className="sr-only">Description for item {i + 1}</label>
                  <Input
                    id={`item-${it.id}-desc`}
                    placeholder="e.g. Labour – fit new radiator"
                    value={it.description}
                    onChange={(e) => onChange(i, { description: e.target.value })}
                    aria-invalid={!!err("description")}
                  />
                  {err("description") && <p className="mt-1 text-xs text-red-600">{err("description")}</p>}
                </div>
              </div>
              <div className="mt-2 grid grid-cols-3 gap-2 md:contents">
                <div className="md:mt-0">
                  <label htmlFor={`item-${it.id}-qty`} className="mb-1 block text-[11px] font-semibold text-navy-500 md:sr-only">Qty</label>
                  <Input
                    id={`item-${it.id}-qty`}
                    inputMode="decimal"
                    className="text-right tabular-nums"
                    value={it.quantity}
                    onChange={(e) => onChange(i, { quantity: e.target.value })}
                    aria-invalid={!!err("quantity")}
                  />
                </div>
                <div>
                  <label htmlFor={`item-${it.id}-price`} className="mb-1 block text-[11px] font-semibold text-navy-500 md:sr-only">Price (£)</label>
                  <Input
                    id={`item-${it.id}-price`}
                    inputMode="decimal"
                    placeholder="0.00"
                    className="text-right tabular-nums"
                    value={it.unitPrice}
                    onChange={(e) => onChange(i, { unitPrice: e.target.value })}
                    aria-invalid={!!err("unitPrice")}
                  />
                </div>
                <div className={cn(!vatEnabled && "invisible")}>
                  <label htmlFor={`item-${it.id}-vat`} className="mb-1 block text-[11px] font-semibold text-navy-500 md:sr-only">VAT</label>
                  <Select
                    id={`item-${it.id}-vat`}
                    value={VAT_RATE_OPTIONS.some((o) => o.value === it.vatRate) ? it.vatRate : "custom"}
                    onChange={(e) => onChange(i, { vatRate: e.target.value === "custom" ? it.vatRate : e.target.value })}
                    disabled={!vatEnabled}
                    tabIndex={vatEnabled ? 0 : -1}
                  >
                    {VAT_RATE_OPTIONS.map((o) => (
                      <option key={o.value} value={o.value}>{o.label}</option>
                    ))}
                    {!VAT_RATE_OPTIONS.some((o) => o.value === it.vatRate) && <option value="custom">{it.vatRate}%</option>}
                  </Select>
                </div>
              </div>
              <div className="mt-2 flex items-center justify-between md:mt-0 md:contents">
                <p className="text-sm font-bold tabular-nums text-navy-900 md:pt-2.5 md:text-right">
                  <span className="mr-2 text-xs font-medium text-navy-400 md:hidden">Amount</span>
                  {formatPence(lineTotals[i] ?? 0)}
                </p>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => onRemove(i)}
                  disabled={items.length === 1}
                  aria-label={`Remove item ${i + 1}`}
                  className="text-navy-400 hover:bg-red-50 hover:text-red-600"
                >
                  <Trash2 />
                </Button>
              </div>
              {(err("quantity") || err("unitPrice") || err("vatRate")) && (
                <p className="mt-1 text-xs text-red-600 md:col-span-6">{err("quantity") || err("unitPrice") || err("vatRate")}</p>
              )}
            </li>
          );
        })}
      </ul>
      {errors.items && <p className="mt-2 text-xs font-medium text-red-600" role="alert">{errors.items}</p>}
      <Button variant="outline" className="mt-3 w-full border-dashed md:w-auto" onClick={onAdd}>
        <Plus /> Add another item
      </Button>
    </div>
  );
}
