"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowLeft,
  Building2,
  Check,
  CreditCard,
  Eye,
  FileDown,
  FileText,
  Loader2,
  NotebookPen,
  Pencil,
  Printer,
  Receipt,
  Save,
  Send,
  Sparkles,
  User,
  X,
} from "lucide-react";
import type { Address, BankDetails, BusinessDetails, CustomerDetails, Invoice, LineItem } from "@/lib/invoice/types";
import { calculateTotals } from "@/lib/invoice/calculations";
import { addDaysISO, formatPence } from "@/lib/invoice/format";
import { PAYMENT_TERM_OPTIONS, VAT_RATE_OPTIONS, defaultTerms, newLineItem } from "@/lib/invoice/defaults";
import { validateInvoice, type Errors } from "@/lib/invoice/validation";
import { StorageError, isOnboarded, saveBank, saveBusiness, saveInvoice, setOnboarded } from "@/lib/invoice/storage";
import { Logo } from "@/components/brand/logo";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Field } from "@/components/ui/field";
import { Input, Select, Textarea } from "@/components/ui/input";
import { InvoicePreview, TEMPLATES } from "./invoice-preview";
import { LineItemsEditor } from "./line-items";
import { LogoUpload } from "./logo-upload";
import { downloadInvoicePdf } from "./download-pdf";
import { cn } from "@/lib/utils";

type Toast = { kind: "success" | "error"; text: string } | null;

function Section({ icon: Icon, title, description, children, id }: { icon: typeof User; title: string; description?: string; children: React.ReactNode; id: string }) {
  return (
    <Card id={id} className="scroll-mt-24">
      <CardHeader>
        <div className="flex items-center gap-3">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-navy-900 text-emerald-400"><Icon className="h-4 w-4" /></span>
          <div>
            <CardTitle>{title}</CardTitle>
            {description && <CardDescription className="text-xs">{description}</CardDescription>}
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">{children}</CardContent>
    </Card>
  );
}

function AddressFields({ prefix, value, onChange, errors, required }: { prefix: string; value: Address; onChange: (p: Partial<Address>) => void; errors: Errors; required?: boolean }) {
  return (
    <div className="grid gap-3 sm:grid-cols-2">
      <Field label="Address line 1" htmlFor={`${prefix}-l1`} error={errors[`${prefix}.address.line1`]} optional={!required} className="sm:col-span-2">
        <Input id={`${prefix}-l1`} autoComplete="address-line1" value={value.line1} onChange={(e) => onChange({ line1: e.target.value })} aria-invalid={!!errors[`${prefix}.address.line1`]} />
      </Field>
      <Field label="Address line 2" htmlFor={`${prefix}-l2`} optional className="sm:col-span-2">
        <Input id={`${prefix}-l2`} autoComplete="address-line2" value={value.line2} onChange={(e) => onChange({ line2: e.target.value })} />
      </Field>
      <Field label="Town / city" htmlFor={`${prefix}-town`}>
        <Input id={`${prefix}-town`} autoComplete="address-level2" value={value.town} onChange={(e) => onChange({ town: e.target.value })} />
      </Field>
      <Field label="County" htmlFor={`${prefix}-county`} optional>
        <Input id={`${prefix}-county`} value={value.county} onChange={(e) => onChange({ county: e.target.value })} />
      </Field>
      <Field label="Postcode" htmlFor={`${prefix}-pc`} error={errors[`${prefix}.address.postcode`]}>
        <Input id={`${prefix}-pc`} autoComplete="postal-code" className="uppercase" value={value.postcode} onChange={(e) => onChange({ postcode: e.target.value })} aria-invalid={!!errors[`${prefix}.address.postcode`]} />
      </Field>
      <Field label="Country" htmlFor={`${prefix}-country`}>
        <Input id={`${prefix}-country`} autoComplete="country-name" value={value.country} onChange={(e) => onChange({ country: e.target.value })} />
      </Field>
    </div>
  );
}

export function InvoiceEditor({ initial, isNew }: { initial: Invoice; isNew: boolean }) {
  const [inv, setInv] = useState<Invoice>(initial);
  const [errors, setErrors] = useState<Errors>({});
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [mobileView, setMobileView] = useState<"edit" | "preview">("edit");
  const [toast, setToast] = useState<Toast>(null);
  const [showWelcome, setShowWelcome] = useState(false);
  const [persisted, setPersisted] = useState(!isNew);
  const toastTimer = useRef<ReturnType<typeof setTimeout>>(undefined);

  useEffect(() => setShowWelcome(isNew && !initial.isSample && !isOnboarded()), [isNew, initial.isSample]);

  const totals = useMemo(() => calculateTotals(inv), [inv]);

  // Warn before leaving with unsaved changes.
  useEffect(() => {
    if (!dirty || inv.isSample) return;
    const handler = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = "";
    };
    window.addEventListener("beforeunload", handler);
    return () => window.removeEventListener("beforeunload", handler);
  }, [dirty, inv.isSample]);

  const notify = useCallback((t: Toast) => {
    setToast(t);
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 4000);
  }, []);

  const update = useCallback((patch: Partial<Invoice>) => {
    setInv((prev) => ({ ...prev, ...patch }));
    setDirty(true);
  }, []);
  const setBusiness = (p: Partial<BusinessDetails>) => update({ business: { ...inv.business, ...p } });
  const setBusinessAddr = (p: Partial<Address>) => setBusiness({ address: { ...inv.business.address, ...p } });
  const setCustomer = (p: Partial<CustomerDetails>) => update({ customer: { ...inv.customer, ...p } });
  const setCustomerAddr = (p: Partial<Address>) => setCustomer({ address: { ...inv.customer.address, ...p } });
  const setBank = (p: Partial<BankDetails>) => update({ bank: { ...inv.bank, ...p } });
  const setItem = (i: number, p: Partial<LineItem>) => update({ items: inv.items.map((it, idx) => (idx === i ? { ...it, ...p } : it)) });

  // Re-validate live once errors are showing, so they clear as the user fixes them.
  useEffect(() => {
    // Only keep errors that are still present, so fixed fields clear instantly.
    if (Object.keys(errors).length) {
      const fresh = validateInvoice(inv);
      setErrors((prev) => Object.fromEntries(Object.keys(prev).filter((k) => fresh[k]).map((k) => [k, fresh[k]])));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [inv]);

  function changeTerms(days: number) {
    const termsWasDefault = inv.terms === defaultTerms(inv.paymentTermsDays) || !inv.terms;
    update({
      paymentTermsDays: days,
      dueDate: days >= 0 ? addDaysISO(inv.issueDate, days) : inv.dueDate,
      terms: termsWasDefault && days >= 0 ? defaultTerms(days) : inv.terms,
    });
  }

  function changeIssueDate(date: string) {
    update({ issueDate: date, dueDate: inv.paymentTermsDays >= 0 && date ? addDaysISO(date, inv.paymentTermsDays) : inv.dueDate });
  }

  function toggleVat(on: boolean) {
    update({ vatEnabled: on, items: on ? inv.items.map((it) => ({ ...it, vatRate: it.vatRate || inv.defaultVatRate })) : inv.items });
  }

  function focusFirstError(errs: Errors) {
    const first = Object.keys(errs)[0];
    if (!first) return;
    const sectionFor = (k: string) =>
      k.startsWith("business") ? "sec-business" : k.startsWith("customer") ? "sec-customer" : k.startsWith("items") || k === "discountValue" ? "sec-items" : k.startsWith("bank") ? "sec-payment" : "sec-details";
    setMobileView("edit");
    requestAnimationFrame(() => document.getElementById(sectionFor(first))?.scrollIntoView({ behavior: "smooth", block: "start" }));
  }

  function persist(next: Invoice, message: string): boolean {
    if (next.isSample) {
      notify({ kind: "error", text: "This is a sample invoice and can't be saved. Start your own invoice instead." });
      return false;
    }
    setSaving(true);
    try {
      const cleaned = { ...next, items: next.items.filter((it, i) => i === 0 || it.description.trim() || it.unitPrice.trim()) };
      const saved = saveInvoice(cleaned);
      saveBusiness(saved.business);
      saveBank(saved.bank);
      setInv(saved);
      setDirty(false);
      setPersisted(true);
      notify({ kind: "success", text: message });
      if (isNew) window.history.replaceState(null, "", `/create?id=${saved.id}`);
      return true;
    } catch (e) {
      notify({ kind: "error", text: e instanceof StorageError ? e.message : "Something went wrong saving. Please try again." });
      return false;
    } finally {
      setSaving(false);
    }
  }

  function handleSave() {
    if (!inv.number.trim()) {
      setErrors({ number: "Give the invoice a number" });
      return focusFirstError({ number: "x" });
    }
    persist(inv, inv.status === "draft" ? "Draft saved" : "Invoice saved");
  }

  function handleMarkSent() {
    const errs = validateInvoice(inv);
    setErrors(errs);
    if (Object.keys(errs).length) {
      notify({ kind: "error", text: "A few details need fixing before this invoice can be sent." });
      return focusFirstError(errs);
    }
    persist({ ...inv, status: "unpaid" }, "Marked as sent — we'll track it as unpaid until you mark it paid.");
  }

  async function handleDownload() {
    const errs = validateInvoice(inv);
    setErrors(errs);
    if (Object.keys(errs).length) {
      notify({ kind: "error", text: "Please fix the highlighted details before downloading." });
      return focusFirstError(errs);
    }
    setDownloading(true);
    try {
      await downloadInvoicePdf(inv, totals);
      notify({ kind: "success", text: "PDF downloaded" });
    } catch (e) {
      console.error(e);
      notify({ kind: "error", text: "We couldn't create the PDF. Please try again, or use Print → Save as PDF." });
    } finally {
      setDownloading(false);
    }
  }

  function handlePrint() {
    setMobileView("preview");
    setTimeout(() => window.print(), 100);
  }

  const e = errors;

  return (
    <div className="min-h-dvh bg-navy-50/70 pb-24 lg:pb-10">
      {/* Top bar */}
      <header className="no-print sticky top-0 z-30 border-b border-navy-100 bg-white/95 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-[1500px] items-center gap-3 px-4 sm:px-6">
          <Link href="/invoices" className="rounded-lg p-2 text-navy-500 hover:bg-navy-50 hover:text-navy-900" aria-label="Back to my invoices">
            <ArrowLeft className="h-5 w-5" />
          </Link>
          <Link href="/" className="hidden sm:block" aria-label="InvoiceFlow home"><Logo /></Link>
          <div className="ml-auto flex items-center gap-2">
            <span className="hidden text-xs text-navy-400 md:inline">
              {inv.isSample ? "Sample — not saved" : dirty ? "Unsaved changes" : persisted ? "All changes saved" : ""}
            </span>
            <Button variant="ghost" size="sm" onClick={handlePrint} className="hidden sm:inline-flex"><Printer /> Print</Button>
            {inv.isSample ? (
              <Button asChild variant="navy" size="sm"><Link href="/create">Start my own invoice</Link></Button>
            ) : (
              <>
                <Button variant="outline" size="sm" onClick={handleSave} disabled={saving}>
                  {saving ? <Loader2 className="animate-spin" /> : <Save />} <span className="hidden sm:inline">Save</span>
                </Button>
                {inv.status === "draft" && (
                  <Button variant="navy" size="sm" onClick={handleMarkSent} disabled={saving} className="hidden md:inline-flex">
                    <Send /> Mark as sent
                  </Button>
                )}
              </>
            )}
            <Button size="sm" onClick={handleDownload} disabled={downloading}>
              {downloading ? <Loader2 className="animate-spin" /> : <FileDown />}
              {downloading ? "Creating PDF…" : "Download PDF"}
            </Button>
          </div>
        </div>
      </header>

      <div className="mx-auto grid max-w-[1500px] gap-6 px-4 pt-6 sm:px-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)] xl:grid-cols-[minmax(0,5fr)_minmax(0,6fr)]">
        {/* ---------- FORM ---------- */}
        <div className={cn("no-print space-y-5", mobileView === "preview" && "hidden lg:block")}>
          {inv.isSample && (
            <div className="flex items-start gap-3 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">
              <Sparkles className="mt-0.5 h-5 w-5 shrink-0" />
              <p>You&apos;re looking at a <strong>sample invoice</strong> with made-up details. Change anything to see the totals update, then <Link href="/create" className="font-semibold underline">start your own</Link>.</p>
            </div>
          )}

          {showWelcome && (
            <div className="relative overflow-hidden rounded-2xl bg-navy-900 p-5 text-white">
              <div className="absolute -right-10 -top-10 h-32 w-32 rounded-full bg-emerald-500/30 blur-2xl" aria-hidden />
              <button className="absolute right-3 top-3 rounded-lg p-1 text-white/60 hover:bg-white/10 hover:text-white" aria-label="Dismiss welcome" onClick={() => { setOnboarded(); setShowWelcome(false); }}>
                <X className="h-4 w-4" />
              </button>
              <p className="font-display text-lg font-bold">Welcome to InvoiceFlow 👋</p>
              <ol className="mt-3 space-y-1.5 text-sm text-navy-100">
                <li><span className="font-bold text-emerald-400">1.</span> Add your business name (we&apos;ll remember it).</li>
                <li><span className="font-bold text-emerald-400">2.</span> Add who it&apos;s for and what you did.</li>
                <li><span className="font-bold text-emerald-400">3.</span> Hit <strong>Download PDF</strong>. That&apos;s it.</li>
              </ol>
              <div className="mt-4 flex flex-wrap gap-2">
                <Button size="sm" onClick={() => { setOnboarded(); setShowWelcome(false); document.getElementById("biz-name")?.focus(); }}>Let&apos;s go</Button>
                <Button asChild size="sm" variant="ghostDark"><Link href="/create?sample=1">See a sample first</Link></Button>
              </div>
            </div>
          )}

          <Section id="sec-business" icon={Building2} title="Your business" description="Saved for your next invoice">
            <Field label="Business or trading name" htmlFor="biz-name" error={e["business.name"]}>
              <Input id="biz-name" autoComplete="organization" placeholder="e.g. J. Smith Plumbing" value={inv.business.name} onChange={(ev) => setBusiness({ name: ev.target.value })} aria-invalid={!!e["business.name"]} />
            </Field>
            <LogoUpload value={inv.business.logoDataUrl} onChange={(logoDataUrl) => setBusiness({ logoDataUrl })} />
            <AddressFields prefix="business" value={inv.business.address} onChange={setBusinessAddr} errors={e} required={inv.vatEnabled} />
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Email" htmlFor="biz-email" error={e["business.email"]} optional>
                <Input id="biz-email" type="email" autoComplete="email" value={inv.business.email} onChange={(ev) => setBusiness({ email: ev.target.value })} aria-invalid={!!e["business.email"]} />
              </Field>
              <Field label="Phone" htmlFor="biz-phone" optional>
                <Input id="biz-phone" type="tel" autoComplete="tel" value={inv.business.phone} onChange={(ev) => setBusiness({ phone: ev.target.value })} />
              </Field>
              <Field label="Company number" htmlFor="biz-co" error={e["business.companyNumber"]} optional hint="Only if you're a limited company">
                <Input id="biz-co" className="uppercase" value={inv.business.companyNumber} onChange={(ev) => setBusiness({ companyNumber: ev.target.value })} aria-invalid={!!e["business.companyNumber"]} />
              </Field>
              <Field label="VAT registration number" htmlFor="biz-vat" error={e["business.vatNumber"]} optional={!inv.vatEnabled} hint="Only if you're VAT registered">
                <Input id="biz-vat" className="uppercase" placeholder="GB123456789" value={inv.business.vatNumber} onChange={(ev) => setBusiness({ vatNumber: ev.target.value })} aria-invalid={!!e["business.vatNumber"]} />
              </Field>
            </div>
          </Section>

          <Section id="sec-customer" icon={User} title="Your customer" description="Who are you billing?">
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Customer or company name" htmlFor="cust-name" error={e["customer.name"]}>
                <Input id="cust-name" value={inv.customer.name} onChange={(ev) => setCustomer({ name: ev.target.value })} aria-invalid={!!e["customer.name"]} />
              </Field>
              <Field label="Contact name" htmlFor="cust-contact" optional>
                <Input id="cust-contact" value={inv.customer.contactName} onChange={(ev) => setCustomer({ contactName: ev.target.value })} />
              </Field>
              <Field label="Email" htmlFor="cust-email" error={e["customer.email"]} optional>
                <Input id="cust-email" type="email" value={inv.customer.email} onChange={(ev) => setCustomer({ email: ev.target.value })} aria-invalid={!!e["customer.email"]} />
              </Field>
              <Field label="Phone" htmlFor="cust-phone" optional>
                <Input id="cust-phone" type="tel" value={inv.customer.phone} onChange={(ev) => setCustomer({ phone: ev.target.value })} />
              </Field>
            </div>
            <AddressFields prefix="customer" value={inv.customer.address} onChange={setCustomerAddr} errors={e} required={inv.vatEnabled} />
          </Section>

          <Section id="sec-details" icon={FileText} title="Invoice details">
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Invoice number" htmlFor="inv-number" error={e.number} hint="Created automatically — change it if you like">
                <Input id="inv-number" className="font-mono" value={inv.number} onChange={(ev) => update({ number: ev.target.value })} aria-invalid={!!e.number} />
              </Field>
              <Field label="Invoice date" htmlFor="inv-date" error={e.issueDate}>
                <Input id="inv-date" type="date" value={inv.issueDate} onChange={(ev) => changeIssueDate(ev.target.value)} aria-invalid={!!e.issueDate} />
              </Field>
              <Field label="Payment terms" htmlFor="inv-terms">
                <Select id="inv-terms" value={inv.paymentTermsDays} onChange={(ev) => changeTerms(Number(ev.target.value))}>
                  {PAYMENT_TERM_OPTIONS.map((o) => <option key={o.days} value={o.days}>{o.label}</option>)}
                  <option value={-1}>Custom due date</option>
                </Select>
              </Field>
              <Field label="Due date" htmlFor="inv-due" error={e.dueDate}>
                <Input id="inv-due" type="date" value={inv.dueDate} onChange={(ev) => update({ dueDate: ev.target.value, paymentTermsDays: -1 })} aria-invalid={!!e.dueDate} />
              </Field>
              {inv.vatEnabled && (
                <Field label="Date of supply (tax point)" htmlFor="inv-supply" optional hint="Only if the work was done on a different date" className="sm:col-span-2">
                  <Input id="inv-supply" type="date" value={inv.supplyDate} onChange={(ev) => update({ supplyDate: ev.target.value })} />
                </Field>
              )}
            </div>
            <fieldset>
              <legend className="mb-2 text-xs font-semibold text-navy-700">Template</legend>
              <div className="grid grid-cols-3 gap-2">
                {TEMPLATES.map((tpl) => (
                  <button
                    key={tpl.id}
                    type="button"
                    onClick={() => update({ template: tpl.id })}
                    aria-pressed={inv.template === tpl.id}
                    className={cn(
                      "rounded-xl border p-3 text-left transition hover:border-emerald-300",
                      inv.template === tpl.id ? "border-emerald-500 bg-emerald-50 ring-1 ring-emerald-500" : "border-navy-100 bg-white"
                    )}
                  >
                    <span className={cn("mb-2 block h-2 rounded-full", tpl.id === "classic" ? "bg-navy-900" : tpl.id === "modern" ? "bg-emerald-500" : "bg-neutral-800")} />
                    <span className="flex items-center justify-between text-sm font-bold text-navy-900">
                      {tpl.name}
                      {inv.template === tpl.id && <Check className="h-4 w-4 text-emerald-600" />}
                    </span>
                    <span className="mt-0.5 hidden text-[11px] text-navy-500 sm:block">{tpl.description}</span>
                  </button>
                ))}
              </div>
            </fieldset>
          </Section>

          <Section id="sec-items" icon={Receipt} title="Items & services" description="Totals update as you type">
            <label className="flex cursor-pointer items-center justify-between gap-4 rounded-xl border border-navy-100 bg-navy-50/50 p-3">
              <span>
                <span className="block text-sm font-semibold text-navy-900">Charge VAT</span>
                <span className="block text-xs text-navy-500">Only switch on if you&apos;re registered for VAT with HMRC</span>
              </span>
              <input type="checkbox" role="switch" className="peer sr-only" checked={inv.vatEnabled} onChange={(ev) => toggleVat(ev.target.checked)} />
              <span className="relative h-6 w-11 shrink-0 rounded-full bg-navy-200 transition peer-checked:bg-emerald-500 peer-focus-visible:ring-2 peer-focus-visible:ring-emerald-500 peer-focus-visible:ring-offset-2 after:absolute after:left-0.5 after:top-0.5 after:h-5 after:w-5 after:rounded-full after:bg-white after:shadow after:transition peer-checked:after:translate-x-5" aria-hidden />
            </label>
            {inv.vatEnabled && (
              <Field label="VAT rate for new items" htmlFor="inv-defvat">
                <Select id="inv-defvat" value={inv.defaultVatRate} onChange={(ev) => update({ defaultVatRate: ev.target.value })}>
                  {VAT_RATE_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                </Select>
              </Field>
            )}
            <LineItemsEditor
              items={inv.items}
              lineTotals={totals.lineTotalsPence}
              vatEnabled={inv.vatEnabled}
              errors={e}
              onChange={setItem}
              onAdd={() => update({ items: [...inv.items, newLineItem(inv.defaultVatRate)] })}
              onRemove={(i) => update({ items: inv.items.filter((_, idx) => idx !== i) })}
            />
            <div className="grid gap-3 border-t border-navy-100 pt-4 sm:grid-cols-2">
              <Field label="Discount" htmlFor="inv-disc-type">
                <Select id="inv-disc-type" value={inv.discountType} onChange={(ev) => update({ discountType: ev.target.value as Invoice["discountType"] })}>
                  <option value="none">No discount</option>
                  <option value="percent">Percentage (%)</option>
                  <option value="fixed">Fixed amount (£)</option>
                </Select>
              </Field>
              {inv.discountType !== "none" && (
                <Field label={inv.discountType === "percent" ? "Discount %" : "Discount £"} htmlFor="inv-disc" error={e.discountValue}>
                  <Input id="inv-disc" inputMode="decimal" value={inv.discountValue} onChange={(ev) => update({ discountValue: ev.target.value })} aria-invalid={!!e.discountValue} />
                </Field>
              )}
            </div>
            <dl className="space-y-1.5 rounded-xl bg-navy-900 p-4 text-sm text-navy-100">
              <div className="flex justify-between"><dt>Subtotal</dt><dd className="tabular-nums">{formatPence(totals.subtotalPence)}</dd></div>
              {totals.discountPence > 0 && <div className="flex justify-between"><dt>Discount</dt><dd className="tabular-nums">−{formatPence(totals.discountPence)}</dd></div>}
              {inv.vatEnabled && <div className="flex justify-between"><dt>VAT</dt><dd className="tabular-nums">{formatPence(totals.vatPence)}</dd></div>}
              <div className="flex justify-between border-t border-white/10 pt-2 text-base font-bold text-white"><dt>Total due</dt><dd className="tabular-nums text-emerald-400">{formatPence(totals.totalPence)}</dd></div>
            </dl>
          </Section>

          <Section id="sec-payment" icon={CreditCard} title="How to pay you" description="Bank details shown on the invoice">
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Account name" htmlFor="bank-name" optional>
                <Input id="bank-name" value={inv.bank.accountName} onChange={(ev) => setBank({ accountName: ev.target.value })} />
              </Field>
              <Field label="Bank" htmlFor="bank-bank" optional>
                <Input id="bank-bank" value={inv.bank.bankName} onChange={(ev) => setBank({ bankName: ev.target.value })} />
              </Field>
              <Field label="Sort code" htmlFor="bank-sort" error={e["bank.sortCode"]} optional>
                <Input id="bank-sort" inputMode="numeric" placeholder="12-34-56" className="font-mono" value={inv.bank.sortCode} onChange={(ev) => setBank({ sortCode: ev.target.value })} aria-invalid={!!e["bank.sortCode"]} />
              </Field>
              <Field label="Account number" htmlFor="bank-acc" error={e["bank.accountNumber"]} optional>
                <Input id="bank-acc" inputMode="numeric" placeholder="12345678" className="font-mono" value={inv.bank.accountNumber} onChange={(ev) => setBank({ accountNumber: ev.target.value })} aria-invalid={!!e["bank.accountNumber"]} />
              </Field>
              <Field label="IBAN" htmlFor="bank-iban" optional hint="For international customers" className="sm:col-span-2">
                <Input id="bank-iban" className="font-mono uppercase" value={inv.bank.iban} onChange={(ev) => setBank({ iban: ev.target.value })} />
              </Field>
            </div>
          </Section>

          <Section id="sec-notes" icon={NotebookPen} title="Notes & terms">
            <Field label="Payment terms" htmlFor="inv-terms-text">
              <Textarea id="inv-terms-text" rows={2} value={inv.terms} onChange={(ev) => update({ terms: ev.target.value })} />
            </Field>
            <Field label="Notes to your customer" htmlFor="inv-notes" optional>
              <Textarea id="inv-notes" rows={2} value={inv.notes} onChange={(ev) => update({ notes: ev.target.value })} />
            </Field>
          </Section>

          {!inv.isSample && inv.status === "draft" && (
            <Button variant="navy" size="lg" className="w-full md:hidden" onClick={handleMarkSent}><Send /> Mark as sent</Button>
          )}
        </div>

        {/* ---------- LIVE PREVIEW ---------- */}
        <div className={cn("lg:block", mobileView === "edit" && "hidden")}>
          <div className="lg:sticky lg:top-22">
            <p className="no-print mb-3 hidden items-center gap-2 text-xs font-semibold uppercase tracking-widest text-navy-400 lg:flex">
              <span className="h-2 w-2 animate-pulse rounded-full bg-emerald-500" /> Live preview
            </p>
            <div className="lg:max-h-[calc(100dvh-8rem)] lg:overflow-y-auto lg:rounded-sm lg:pb-4">
              <InvoicePreview invoice={inv} totals={totals} />
            </div>
          </div>
        </div>
      </div>

      {/* Mobile edit/preview switcher */}
      <div className="no-print fixed inset-x-0 bottom-0 z-30 border-t border-navy-100 bg-white p-3 lg:hidden">
        <div className="mx-auto grid max-w-md grid-cols-2 gap-1 rounded-xl bg-navy-50 p-1">
          {(["edit", "preview"] as const).map((v) => (
            <button
              key={v}
              onClick={() => { setMobileView(v); window.scrollTo({ top: 0 }); }}
              className={cn("flex items-center justify-center gap-2 rounded-lg py-2.5 text-sm font-semibold transition", mobileView === v ? "bg-white text-navy-900 shadow" : "text-navy-500")}
              aria-pressed={mobileView === v}
            >
              {v === "edit" ? <Pencil className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              {v === "edit" ? "Edit" : `Preview · ${formatPence(totals.totalPence)}`}
            </button>
          ))}
        </div>
      </div>

      {/* Toast */}
      {toast && (
        <div role="status" className={cn("no-print fixed bottom-24 left-1/2 z-50 flex max-w-[90vw] -translate-x-1/2 animate-fade-up items-center gap-2 rounded-xl px-4 py-3 text-sm font-medium shadow-2xl lg:bottom-6", toast.kind === "success" ? "bg-navy-900 text-white" : "bg-red-600 text-white")}>
          {toast.kind === "success" ? <Check className="h-4 w-4 text-emerald-400" /> : <X className="h-4 w-4" />}
          {toast.text}
        </div>
      )}
    </div>
  );
}
