// Real PDF generation using @react-pdf/renderer. This file is only ever loaded
// in the browser, on demand, when someone clicks "Download PDF" (see
// download-pdf.ts), so it doesn't slow down the first page load.

import { Document, Image, Page, StyleSheet, Text, View } from "@react-pdf/renderer";
import type { Invoice } from "@/lib/invoice/types";
import type { Totals } from "@/lib/invoice/calculations";
import { toBasisPoints, toPence } from "@/lib/invoice/calculations";
import { addressLines, companyFooter, formatDateUK, formatPence, formatRate, formatSortCode } from "@/lib/invoice/format";

const PALETTE = {
  classic: { headBg: "#0b1630", headText: "#ffffff", title: "#34d399", accent: "#0b1630", tableBg: "#f2f5fb", tableText: "#1f3159", totalBg: "#0b1630", totalText: "#ffffff", rule: "#e3e9f5", headBorder: "#0b1630" },
  modern: { headBg: "#ffffff", headText: "#0b1630", title: "#059669", accent: "#059669", tableBg: "#ecfdf5", tableText: "#047857", totalBg: "#10b981", totalText: "#060d1f", rule: "#d1fae5", headBorder: "#10b981" },
  minimal: { headBg: "#ffffff", headText: "#111111", title: "#111111", accent: "#111111", tableBg: "#ffffff", tableText: "#111111", totalBg: "#ffffff", totalText: "#111111", rule: "#dddddd", headBorder: "#111111" },
};

const s = StyleSheet.create({
  page: { fontFamily: "Helvetica", fontSize: 9, color: "#262626", paddingBottom: 48 },
  header: { flexDirection: "row", justifyContent: "space-between", paddingHorizontal: 36, paddingVertical: 26 },
  bizName: { fontFamily: "Helvetica-Bold", fontSize: 14, marginBottom: 3 },
  muted: { color: "#737373" },
  title: { fontFamily: "Helvetica-Bold", fontSize: 20, textTransform: "uppercase", textAlign: "right" },
  body: { paddingHorizontal: 36, paddingTop: 22 },
  row: { flexDirection: "row" },
  label: { fontFamily: "Helvetica-Bold", fontSize: 7, letterSpacing: 1, textTransform: "uppercase", marginBottom: 3 },
  th: { fontFamily: "Helvetica-Bold", paddingVertical: 6, paddingHorizontal: 6 },
  td: { paddingVertical: 6, paddingHorizontal: 6 },
  right: { textAlign: "right" },
  totalsBox: { width: 220, marginLeft: "auto", marginTop: 14 },
  totalLine: { flexDirection: "row", justifyContent: "space-between", marginBottom: 4 },
  footer: { position: "absolute", bottom: 18, left: 36, right: 36, fontSize: 7, color: "#737373", borderTopWidth: 1, paddingTop: 6 },
});

const COL = { desc: "46%", qty: "10%", price: "16%", vat: "10%", amount: "18%" };

export function InvoicePdf({ invoice, totals }: { invoice: Invoice; totals: Totals }) {
  const p = PALETTE[invoice.template];
  const b = invoice.business;
  const c = invoice.customer;
  const vat = invoice.vatEnabled;
  const items = invoice.items.filter((it) => it.description.trim() || it.unitPrice.trim());
  const descWidth = vat ? COL.desc : "56%";
  const footer = companyFooter(b);
  const hasBank = invoice.bank.accountNumber || invoice.bank.sortCode || invoice.bank.iban;

  return (
    <Document title={`${invoice.number} - ${b.name}`} author={b.name} creator="InvoiceFlow" producer="InvoiceFlow">
      <Page size="A4" style={s.page}>
        <View style={[s.header, { backgroundColor: p.headBg, color: p.headText, borderBottomWidth: invoice.template === "classic" ? 0 : invoice.template === "modern" ? 3 : 1, borderBottomColor: p.headBorder }]}>
          <View style={{ maxWidth: "60%" }}>
            {b.logoDataUrl ? <Image src={b.logoDataUrl} style={{ maxHeight: 44, maxWidth: 150, objectFit: "contain", marginBottom: 8 }} /> : null}
            <Text style={s.bizName}>{b.name}</Text>
            {[...addressLines(b.address), b.email, b.phone, b.website].filter(Boolean).map((l, i) => (
              <Text key={i} style={{ opacity: 0.8 }}>{l}</Text>
            ))}
          </View>
          <View>
            <Text style={[s.title, { color: p.title }]}>{vat ? "VAT Invoice" : "Invoice"}</Text>
            <Text style={[s.right, { fontFamily: "Courier", fontSize: 10, marginTop: 3 }]}>{invoice.number}</Text>
          </View>
        </View>

        <View style={s.body}>
          <View style={[s.row, { justifyContent: "space-between" }]}>
            <View style={{ maxWidth: "55%" }}>
              <Text style={[s.label, { color: p.accent }]}>Bill to</Text>
              <Text style={{ fontFamily: "Helvetica-Bold", fontSize: 10 }}>{c.name}</Text>
              {c.contactName ? <Text>FAO {c.contactName}</Text> : null}
              {[...addressLines(c.address), c.email, c.phone].filter(Boolean).map((l, i) => <Text key={i}>{l}</Text>)}
            </View>
            <View style={{ width: 190 }}>
              {[
                ["Invoice date", formatDateUK(invoice.issueDate)],
                ...(vat && invoice.supplyDate && invoice.supplyDate !== invoice.issueDate ? [["Tax point", formatDateUK(invoice.supplyDate)]] : []),
                ["Due date", invoice.paymentTermsDays === 0 ? "On receipt" : formatDateUK(invoice.dueDate)],
                ["Amount due", formatPence(totals.totalPence)],
              ].map(([k, v]) => (
                <View key={k} style={[s.totalLine, { marginBottom: 3 }]}>
                  <Text style={s.muted}>{k}</Text>
                  <Text style={{ fontFamily: "Helvetica-Bold", color: k === "Amount due" ? p.accent : "#262626" }}>{v}</Text>
                </View>
              ))}
            </View>
          </View>

          <View style={{ marginTop: 22 }}>
            <View style={[s.row, { backgroundColor: p.tableBg, color: p.tableText, borderBottomWidth: invoice.template === "minimal" ? 1 : 0, borderBottomColor: "#111" }]} fixed>
              <Text style={[s.th, { width: descWidth }]}>Description</Text>
              <Text style={[s.th, s.right, { width: COL.qty }]}>Qty</Text>
              <Text style={[s.th, s.right, { width: COL.price }]}>Unit price</Text>
              {vat ? <Text style={[s.th, s.right, { width: COL.vat }]}>VAT</Text> : null}
              <Text style={[s.th, s.right, { width: COL.amount }]}>Amount</Text>
            </View>
            {items.map((it) => (
              <View key={it.id} style={[s.row, { borderBottomWidth: 1, borderBottomColor: p.rule }]} wrap={false}>
                <Text style={[s.td, { width: descWidth }]}>{it.description}</Text>
                <Text style={[s.td, s.right, { width: COL.qty }]}>{it.quantity}</Text>
                <Text style={[s.td, s.right, { width: COL.price }]}>{formatPence(toPence(it.unitPrice) ?? 0)}</Text>
                {vat ? <Text style={[s.td, s.right, { width: COL.vat }]}>{formatRate(toBasisPoints(it.vatRate) ?? 0)}</Text> : null}
                <Text style={[s.td, s.right, { width: COL.amount, fontFamily: "Helvetica-Bold" }]}>
                  {formatPence(totals.lineTotalsPence[invoice.items.indexOf(it)] ?? 0)}
                </Text>
              </View>
            ))}
          </View>

          <View style={s.totalsBox} wrap={false}>
            <View style={s.totalLine}><Text style={s.muted}>Subtotal</Text><Text>{formatPence(totals.subtotalPence)}</Text></View>
            {totals.discountPence > 0 ? (
              <View style={s.totalLine}>
                <Text style={s.muted}>Discount{invoice.discountType === "percent" ? ` (${invoice.discountValue}%)` : ""}</Text>
                <Text>-{formatPence(totals.discountPence)}</Text>
              </View>
            ) : null}
            {vat && totals.discountPence > 0 ? (
              <View style={s.totalLine}><Text style={s.muted}>Net total</Text><Text>{formatPence(totals.netPence)}</Text></View>
            ) : null}
            {vat
              ? totals.vatBands.map((band) => (
                  <View key={band.rateBp} style={s.totalLine}>
                    <Text style={s.muted}>VAT {formatRate(band.rateBp)} on {formatPence(band.netPence)}</Text>
                    <Text>{formatPence(band.vatPence)}</Text>
                  </View>
                ))
              : null}
            <View
              style={[
                s.totalLine,
                {
                  backgroundColor: p.totalBg,
                  color: p.totalText,
                  paddingVertical: 7,
                  paddingHorizontal: 8,
                  marginTop: 6,
                  borderRadius: invoice.template === "minimal" ? 0 : 4,
                  borderTopWidth: invoice.template === "minimal" ? 1.5 : 0,
                  borderBottomWidth: invoice.template === "minimal" ? 1.5 : 0,
                },
              ]}
            >
              <Text style={{ fontFamily: "Helvetica-Bold" }}>Total due</Text>
              <Text style={{ fontFamily: "Helvetica-Bold", fontSize: 12 }}>{formatPence(totals.totalPence)}</Text>
            </View>
          </View>

          <View style={[s.row, { marginTop: 26, justifyContent: "space-between" }]} wrap={false}>
            <View style={{ width: "46%" }}>
              {hasBank ? (
                <>
                  <Text style={[s.label, { color: p.accent }]}>Payment details</Text>
                  {[
                    ["Account name", invoice.bank.accountName],
                    ["Bank", invoice.bank.bankName],
                    ["Sort code", invoice.bank.sortCode && formatSortCode(invoice.bank.sortCode)],
                    ["Account no.", invoice.bank.accountNumber],
                    ["IBAN", invoice.bank.iban],
                    ["Reference", invoice.number],
                  ]
                    .filter(([, v]) => v)
                    .map(([k, v]) => (
                      <View key={k} style={s.row}>
                        <Text style={[s.muted, { width: 70 }]}>{k}</Text>
                        <Text>{v}</Text>
                      </View>
                    ))}
                </>
              ) : null}
            </View>
            <View style={{ width: "48%" }}>
              {invoice.terms ? (
                <View style={{ marginBottom: 10 }}>
                  <Text style={[s.label, { color: p.accent }]}>Payment terms</Text>
                  <Text>{invoice.terms}</Text>
                </View>
              ) : null}
              {invoice.notes ? (
                <View>
                  <Text style={[s.label, { color: p.accent }]}>Notes</Text>
                  <Text>{invoice.notes}</Text>
                </View>
              ) : null}
            </View>
          </View>
        </View>

        <View style={[s.footer, { borderTopColor: p.rule }]} fixed>
          <Text>{footer}</Text>
          <Text render={({ pageNumber, totalPages }) => (totalPages > 1 ? `Page ${pageNumber} of ${totalPages}` : "")} style={{ position: "absolute", right: 0, top: 6 }} />
        </View>
      </Page>
    </Document>
  );
}
