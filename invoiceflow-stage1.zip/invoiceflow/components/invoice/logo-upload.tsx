"use client";

import { useRef, useState } from "react";
import { ImagePlus, Loader2, X } from "lucide-react";
import { Button } from "@/components/ui/button";

const MAX_INPUT_BYTES = 5 * 1024 * 1024;
const MAX_DIMENSION = 400;

/** Shrinks the image to at most 400px so it stays small in storage and PDFs. */
function resize(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const scale = Math.min(1, MAX_DIMENSION / Math.max(img.width, img.height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.max(1, Math.round(img.width * scale));
      canvas.height = Math.max(1, Math.round(img.height * scale));
      const ctx = canvas.getContext("2d");
      if (!ctx) return reject(new Error("no canvas"));
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      URL.revokeObjectURL(url);
      resolve(canvas.toDataURL("image/png"));
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("bad image"));
    };
    img.src = url;
  });
}

export function LogoUpload({ value, onChange }: { value: string; onChange: (dataUrl: string) => void }) {
  const input = useRef<HTMLInputElement>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function handle(file?: File) {
    setError("");
    if (!file) return;
    if (!["image/png", "image/jpeg"].includes(file.type)) return setError("Please choose a PNG or JPG image.");
    if (file.size > MAX_INPUT_BYTES) return setError("That image is over 5 MB. Please choose a smaller one.");
    setBusy(true);
    try {
      onChange(await resize(file));
    } catch {
      setError("We couldn't read that image. Try a different file.");
    } finally {
      setBusy(false);
      if (input.current) input.current.value = "";
    }
  }

  return (
    <div>
      <div className="flex items-center gap-3">
        <div className="flex h-16 w-28 items-center justify-center overflow-hidden rounded-lg border border-dashed border-navy-200 bg-navy-50">
          {value ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={value} alt="Your logo" className="max-h-full max-w-full object-contain" />
          ) : (
            <ImagePlus className="h-5 w-5 text-navy-300" aria-hidden />
          )}
        </div>
        <div className="flex flex-col gap-1.5">
          <Button type="button" variant="outline" size="sm" onClick={() => input.current?.click()} disabled={busy}>
            {busy ? <Loader2 className="animate-spin" /> : null}
            {value ? "Change logo" : "Upload logo"}
          </Button>
          {value && (
            <Button type="button" variant="ghost" size="sm" onClick={() => onChange("")} className="text-navy-500">
              <X /> Remove
            </Button>
          )}
        </div>
        <input
          ref={input}
          type="file"
          accept="image/png,image/jpeg"
          className="sr-only"
          aria-label="Upload business logo"
          onChange={(e) => handle(e.target.files?.[0])}
        />
      </div>
      {error ? <p className="mt-1.5 text-xs font-medium text-red-600" role="alert">{error}</p> : <p className="mt-1.5 text-xs text-navy-400">PNG or JPG. We&apos;ll resize it for you.</p>}
    </div>
  );
}
