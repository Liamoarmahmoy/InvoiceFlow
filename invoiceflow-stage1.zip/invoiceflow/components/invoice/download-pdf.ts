"use client";

import { createElement } from "react";
import type { Invoice } from "@/lib/invoice/types";
import type { Totals } from "@/lib/invoice/calculations";

/** Builds the PDF in the browser and triggers a download. */
export async function downloadInvoicePdf(invoice: Invoice, totals: Totals) {
  // Loaded on demand so the PDF library only downloads when it's needed.
  const [{ pdf }, { InvoicePdf }] = await Promise.all([import("@react-pdf/renderer"), import("./invoice-pdf")]);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const blob = await pdf(createElement(InvoicePdf, { invoice, totals }) as any).toBlob();
  const safe = (s: string) => s.replace(/[^a-z0-9-_]+/gi, "-").replace(/^-+|-+$/g, "");
  const filename = `${safe(invoice.number) || "invoice"}${invoice.customer.name ? `-${safe(invoice.customer.name)}` : ""}.pdf`;
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10_000);
}
