import type { Invoice, TemplateId } from "@/lib/invoice/types";
import type { Totals } from "@/lib/invoice/calculations";
import { addressLines, companyFooter, formatDateUK, formatPence, formatRate, formatSortCode } from "@/lib/invoice/format";
import { toBasisPoints, toPence } from "@/lib/invoice/calculations";
import { cn } from "@/lib/utils";

export const TEMPLATES: { id: TemplateId; name: string; description: string }[] = [
  { id: "classic", name: "Classic", description: "Navy header, timeless and formal" },
  { id: "modern", name: "Modern", description: "Emerald accents, bold totals" },
  { id: "minimal", name: "Minimal", description: "Clean black and white" },
];

const THEME = {
  classic: { head: "bg-navy-900 text-white", accent: "text-navy-900", tableHead: "bg-navy-50 text-navy-700", total: "bg-navy-900 text-white", rule: "border-navy-100" },
  modern: { head: "bg-white text-navy-900 border-b-4 border-emerald-500", accent: "text-emerald-600", tableHead: "bg-emerald-50 text-emerald-800", total: "bg-emerald-500 text-navy-950", rule: "border-emerald-100" },
  minimal: { head: "bg-white text-neutral-900 border-b border-neutral-900", accent: "text-neutral-900", tableHead: "border-b border-neutral-900 text-neutral-900", total: "border-y-2 border-neutral-900 text-neutral-900", rule: "border-neutral-200" },
} as const;

export function InvoicePreview({ invoice, totals, className }: { invoice: Invoice; totals: Totals; className?: string }) {
  const t = THEME[invoice.template];
  const b = invoice.business;
  const c = invoice.customer;
  const title = invoice.vatEnabled ? "VAT Invoice" : "Invoice";
  const items = invoice.items.filter((it) => it.description.trim() || it.unitPrice.trim());
  const hasBank = invoice.bank.accountNumber || invoice.bank.sortCode || invoice.bank.iban;

  return (
    <article
      className={cn("print-area relative mx-auto w-full bg-white text-[11px] leading-relaxed text-neutral-800 shadow-xl ring-1 ring-black/5 sm:text-xs", className)}
      aria-label="Invoice preview"
    >
      {invoice.isSample && (
        <div className="no-print absolute right-3 top-3 z-10 rounded-full bg-amber-400 px-2.5 py-1 text-[10px] font-extrabold uppercase tracking-wider text-amber-950">Sample</div>
      )}
      <header className={cn("flex flex-wrap items-start justify-between gap-6 px-6 py-6 sm:px-10 sm:py-8", t.head)}>
        <div className="min-w-0">
          {b.logoDataUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={b.logoDataUrl} alt={`${b.name || "Business"} logo`} className="mb-3 max-h-14 max-w-[180px] object-contain" />
          ) : null}
          <p className="font-display text-lg font-extrabold sm:text-xl">{b.name || "Your Business Name"}</p>
          <div className="mt-1 opacity-75">
            {addressLines(b.address).map((l) => <p key={l}>{l}</p>)}
            {b.email && <p>{b.email}</p>}
            {b.phone && <p>{b.phone}</p>}
            {b.website && <p>{b.website}</p>}
          </div>
        </div>
        <div className="text-right">
          <p className={cn("font-display text-2xl font-extrabold uppercase tracking-wide sm:text-3xl", invoice.template === "classic" ? "text-emerald-400" : t.accent)}>{title}</p>
          <p className="mt-1 font-mono text-sm">{invoice.number || "—"}</p>
        </div>
      </header>

      <div className="px-6 py-6 sm:px-10 sm:py-8">
        <div className="grid gap-6 sm:grid-cols-2">
          <div>
            <p className={cn("text-[10px] font-bold uppercase tracking-widest", t.accent)}>Bill to</p>
            <p className="mt-1 text-sm font-bold text-neutral-900">{c.name || "Customer name"}</p>
            {c.contactName && <p>FAO {c.contactName}</p>}
            {addressLines(c.address).map((l) => <p key={l}>{l}</p>)}
            {c.email && <p>{c.email}</p>}
            {c.phone && <p>{c.phone}</p>}
          </div>
          <dl className="grid grid-cols-[auto_1fr] gap-x-4 gap-y-1 sm:justify-self-end">
            <dt className="text-neutral-500">Invoice date</dt>
            <dd className="text-right font-semibold">{formatDateUK(invoice.issueDate)}</dd>
            {invoice.vatEnabled && invoice.supplyDate && invoice.supplyDate !== invoice.issueDate && (
              <>
                <dt className="text-neutral-500">Tax point</dt>
                <dd className="text-right font-semibold">{formatDateUK(invoice.supplyDate)}</dd>
              </>
            )}
            <dt className="text-neutral-500">Due date</dt>
            <dd className="text-right font-semibold">{invoice.paymentTermsDays === 0 ? "On receipt" : formatDateUK(invoice.dueDate)}</dd>
            <dt className="text-neutral-500">Amount due</dt>
            <dd className={cn("text-right font-bold", t.accent)}>{formatPence(totals.totalPence)}</dd>
          </dl>
        </div>

        <table className="mt-8 w-full text-left">
          <thead>
            <tr className={t.tableHead}>
              <th className="px-2 py-2 font-semibold sm:px-3">Description</th>
              <th className="px-2 py-2 text-right font-semibold sm:px-3">Qty</th>
              <th className="px-2 py-2 text-right font-semibold sm:px-3">Unit price</th>
              {invoice.vatEnabled && <th className="px-2 py-2 text-right font-semibold sm:px-3">VAT</th>}
              <th className="px-2 py-2 text-right font-semibold sm:px-3">Amount</th>
            </tr>
          </thead>
          <tbody>
            {items.length === 0 ? (
              <tr>
                <td colSpan={5} className="px-3 py-6 text-center text-neutral-400">Your items will appear here</td>
              </tr>
            ) : (
              items.map((it) => {
                const idx = invoice.items.indexOf(it);
                return (
                  <tr key={it.id} className={cn("border-b align-top", t.rule)}>
                    <td className="whitespace-pre-wrap break-words px-2 py-2.5 sm:px-3">{it.description}</td>
                    <td className="px-2 py-2.5 text-right tabular-nums sm:px-3">{it.quantity}</td>
                    <td className="px-2 py-2.5 text-right tabular-nums sm:px-3">{formatPence(toPence(it.unitPrice) ?? 0)}</td>
                    {invoice.vatEnabled && <td className="px-2 py-2.5 text-right tabular-nums sm:px-3">{formatRate(toBasisPoints(it.vatRate) ?? 0)}</td>}
                    <td className="px-2 py-2.5 text-right font-medium tabular-nums sm:px-3">{formatPence(totals.lineTotalsPence[idx] ?? 0)}</td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>

        <div className="mt-6 flex justify-end">
          <dl className="w-full max-w-[260px] space-y-1.5">
            <div className="flex justify-between"><dt className="text-neutral-500">Subtotal</dt><dd className="tabular-nums">{formatPence(totals.subtotalPence)}</dd></div>
            {totals.discountPence > 0 && (
              <div className="flex justify-between">
                <dt className="text-neutral-500">Discount{invoice.discountType === "percent" ? ` (${invoice.discountValue}%)` : ""}</dt>
                <dd className="tabular-nums">−{formatPence(totals.discountPence)}</dd>
              </div>
            )}
            {invoice.vatEnabled && (
              <>
                {totals.discountPence > 0 && (
                  <div className="flex justify-between"><dt className="text-neutral-500">Net total</dt><dd className="tabular-nums">{formatPence(totals.netPence)}</dd></div>
                )}
                {totals.vatBands.map((band) => (
                  <div key={band.rateBp} className="flex justify-between">
                    <dt className="text-neutral-500">VAT {formatRate(band.rateBp)} on {formatPence(band.netPence)}</dt>
                    <dd className="tabular-nums">{formatPence(band.vatPence)}</dd>
                  </div>
                ))}
              </>
            )}
            <div className={cn("mt-2 flex items-center justify-between px-3 py-2.5", t.total, invoice.template !== "minimal" && "rounded-lg")}>
              <dt className="font-bold">Total due</dt>
              <dd className="font-display text-base font-extrabold tabular-nums">{formatPence(totals.totalPence)}</dd>
            </div>
          </dl>
        </div>

        <div className="mt-8 grid gap-6 sm:grid-cols-2">
          {hasBank ? (
            <div>
              <p className={cn("text-[10px] font-bold uppercase tracking-widest", t.accent)}>Payment details</p>
              <dl className="mt-1 grid grid-cols-[auto_1fr] gap-x-3">
                {invoice.bank.accountName && (<><dt className="text-neutral-500">Account name</dt><dd>{invoice.bank.accountName}</dd></>)}
                {invoice.bank.bankName && (<><dt className="text-neutral-500">Bank</dt><dd>{invoice.bank.bankName}</dd></>)}
                {invoice.bank.sortCode && (<><dt className="text-neutral-500">Sort code</dt><dd className="font-mono">{formatSortCode(invoice.bank.sortCode)}</dd></>)}
                {invoice.bank.accountNumber && (<><dt className="text-neutral-500">Account no.</dt><dd className="font-mono">{invoice.bank.accountNumber}</dd></>)}
                {invoice.bank.iban && (<><dt className="text-neutral-500">IBAN</dt><dd className="font-mono">{invoice.bank.iban}</dd></>)}
                <dt className="text-neutral-500">Reference</dt><dd className="font-mono">{invoice.number}</dd>
              </dl>
            </div>
          ) : <div />}
          <div className="space-y-3">
            {invoice.terms && (
              <div>
                <p className={cn("text-[10px] font-bold uppercase tracking-widest", t.accent)}>Payment terms</p>
                <p className="mt-1 whitespace-pre-wrap">{invoice.terms}</p>
              </div>
            )}
            {invoice.notes && (
              <div>
                <p className={cn("text-[10px] font-bold uppercase tracking-widest", t.accent)}>Notes</p>
                <p className="mt-1 whitespace-pre-wrap">{invoice.notes}</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {(b.companyNumber || b.vatNumber) && (
        <footer className={cn("border-t px-6 py-4 text-[10px] text-neutral-500 sm:px-10", t.rule)}>
          {companyFooter(b)}
        </footer>
      )}
    </article>
  );
}
