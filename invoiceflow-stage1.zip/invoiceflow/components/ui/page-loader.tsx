import { Loader2 } from "lucide-react";

export function PageLoader({ label = "Loading…" }: { label?: string }) {
  return (
    <div className="flex min-h-dvh items-center justify-center bg-navy-50/60" role="status" aria-live="polite">
      <div className="flex items-center gap-3 text-sm font-medium text-navy-500">
        <Loader2 className="h-5 w-5 animate-spin text-emerald-500" /> {label}
      </div>
    </div>
  );
}
