import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const badgeVariants = cva("inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-semibold", {
  variants: {
    variant: {
      default: "bg-navy-100 text-navy-700",
      draft: "bg-slate-100 text-slate-700 ring-1 ring-slate-200",
      unpaid: "bg-amber-50 text-amber-800 ring-1 ring-amber-200",
      paid: "bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200",
      overdue: "bg-red-50 text-red-700 ring-1 ring-red-200",
      emerald: "bg-emerald-500/15 text-emerald-300 ring-1 ring-emerald-400/30",
    },
  },
  defaultVariants: { variant: "default" },
});

export function Badge({ className, variant, ...props }: React.HTMLAttributes<HTMLSpanElement> & VariantProps<typeof badgeVariants>) {
  return <span className={cn(badgeVariants({ variant }), className)} {...props} />;
}
