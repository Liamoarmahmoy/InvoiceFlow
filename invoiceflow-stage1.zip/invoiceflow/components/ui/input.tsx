import * as React from "react";
import { cn } from "@/lib/utils";

const fieldBase =
  "w-full rounded-lg border border-navy-200 bg-white px-3 text-sm text-navy-900 shadow-xs transition placeholder:text-navy-300 focus:border-emerald-500 focus:outline-none focus:ring-3 focus:ring-emerald-500/15 disabled:cursor-not-allowed disabled:bg-navy-50 aria-[invalid=true]:border-red-400 aria-[invalid=true]:ring-red-500/10";

const Input = React.forwardRef<HTMLInputElement, React.InputHTMLAttributes<HTMLInputElement>>(
  ({ className, ...props }, ref) => <input ref={ref} className={cn(fieldBase, "h-10", className)} {...props} />
);
Input.displayName = "Input";

const Textarea = React.forwardRef<HTMLTextAreaElement, React.TextareaHTMLAttributes<HTMLTextAreaElement>>(
  ({ className, ...props }, ref) => <textarea ref={ref} className={cn(fieldBase, "min-h-20 py-2", className)} {...props} />
);
Textarea.displayName = "Textarea";

const Select = React.forwardRef<HTMLSelectElement, React.SelectHTMLAttributes<HTMLSelectElement>>(
  ({ className, ...props }, ref) => <select ref={ref} className={cn(fieldBase, "h-10 pr-8", className)} {...props} />
);
Select.displayName = "Select";

export { Input, Textarea, Select };
