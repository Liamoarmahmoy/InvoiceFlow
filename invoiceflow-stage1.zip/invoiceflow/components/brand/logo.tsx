import { cn } from "@/lib/utils";

/** InvoiceFlow mark: a folded document whose lines flow into a tick. */
export function LogoMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 40 40" className={cn("h-8 w-8", className)} aria-hidden="true">
      <defs>
        <linearGradient id="if-g" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#34d399" />
          <stop offset="1" stopColor="#059669" />
        </linearGradient>
      </defs>
      <rect width="40" height="40" rx="10" fill="#0b1630" />
      <path d="M12 9h11l6 6v16a2 2 0 0 1-2 2H12a2 2 0 0 1-2-2V11a2 2 0 0 1 2-2z" fill="#fff" />
      <path d="M23 9v4a2 2 0 0 0 2 2h4" fill="#c3cfe6" />
      <rect x="14" y="17" width="9" height="2" rx="1" fill="#c3cfe6" />
      <rect x="14" y="21" width="6" height="2" rx="1" fill="#c3cfe6" />
      <path d="M16.5 27.2l2.6 2.6 5.6-6" stroke="url(#if-g)" strokeWidth="3" fill="none" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function Logo({ dark = false, className }: { dark?: boolean; className?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-2.5", className)}>
      <LogoMark />
      <span className={cn("font-display text-xl font-extrabold tracking-tight", dark ? "text-white" : "text-navy-900")}>
        Invoice<span className="text-emerald-500">Flow</span>
      </span>
    </span>
  );
}
