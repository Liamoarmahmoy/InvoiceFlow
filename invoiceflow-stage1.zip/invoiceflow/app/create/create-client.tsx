"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";
import type { Invoice } from "@/lib/invoice/types";
import { blankInvoice, sampleInvoice, uid } from "@/lib/invoice/defaults";
import { addDaysISO, todayISO } from "@/lib/invoice/format";
import { getInvoice, loadBank, loadBusiness, nextInvoiceNumber } from "@/lib/invoice/storage";
import { InvoiceEditor } from "@/components/invoice/invoice-editor";
import { PageLoader } from "@/components/ui/page-loader";
import { Button } from "@/components/ui/button";

type State = { kind: "loading" } | { kind: "ready"; invoice: Invoice; isNew: boolean } | { kind: "missing" };

export function CreateInvoiceClient() {
  const params = useSearchParams();
  const [state, setState] = useState<State>({ kind: "loading" });

  // Runs once in the browser (invoice data lives in browser storage in Stage 1).
  useEffect(() => {
    const id = params.get("id");
    const from = params.get("from");
    if (params.get("sample")) {
      setState({ kind: "ready", invoice: sampleInvoice("INV-SAMPLE"), isNew: true });
    } else if (id) {
      const inv = getInvoice(id);
      setState(inv ? { kind: "ready", invoice: inv, isNew: false } : { kind: "missing" });
    } else if (from) {
      const src = getInvoice(from);
      if (!src) return setState({ kind: "missing" });
      const issue = todayISO();
      const now = new Date().toISOString();
      setState({
        kind: "ready",
        isNew: true,
        invoice: {
          ...src,
          id: uid(),
          number: nextInvoiceNumber(),
          status: "draft",
          issueDate: issue,
          supplyDate: "",
          dueDate: addDaysISO(issue, Math.max(src.paymentTermsDays, 0)),
          paymentTermsDays: src.paymentTermsDays < 0 ? 14 : src.paymentTermsDays,
          items: src.items.map((it) => ({ ...it, id: uid() })),
          createdAt: now,
          updatedAt: now,
        },
      });
    } else {
      setState({ kind: "ready", invoice: blankInvoice(nextInvoiceNumber(), loadBusiness() ?? undefined, loadBank() ?? undefined), isNew: true });
    }
    // Intentionally only on first load: saving updates the URL without re-initialising.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (state.kind === "loading") return <PageLoader label="Loading invoice editor…" />;
  if (state.kind === "missing")
    return (
      <div className="flex min-h-dvh flex-col items-center justify-center gap-4 p-6 text-center">
        <h1 className="font-display text-2xl font-bold">We couldn&apos;t find that invoice</h1>
        <p className="max-w-md text-navy-500">It may have been deleted, or saved in a different browser. Invoices are stored on the device where they were created.</p>
        <div className="flex gap-2">
          <Button asChild variant="outline"><Link href="/invoices">My invoices</Link></Button>
          <Button asChild><Link href="/create">Create a new invoice</Link></Button>
        </div>
      </div>
    );
  return <InvoiceEditor initial={state.invoice} isNew={state.isNew} />;
}
