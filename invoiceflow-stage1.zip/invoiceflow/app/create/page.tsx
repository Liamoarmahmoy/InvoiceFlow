import type { Metadata } from "next";
import { Suspense } from "react";
import { CreateInvoiceClient } from "./create-client";
import { PageLoader } from "@/components/ui/page-loader";

export const metadata: Metadata = { title: "Create an invoice" };

export default function CreatePage() {
  return (
    <Suspense fallback={<PageLoader label="Loading invoice editor…" />}>
      <CreateInvoiceClient />
    </Suspense>
  );
}
