import Link from "next/link";
import {
  ArrowRight,
  BadgePoundSterling,
  Building2,
  Calculator,
  Copy,
  FileDown,
  LayoutTemplate,
  ShieldCheck,
  Smartphone,
  Sparkles,
  Timer,
  Users,
} from "lucide-react";
import { SiteHeader } from "@/components/landing/site-header";
import { Pricing } from "@/components/landing/pricing";
import { SiteFooter } from "@/components/landing/site-footer";
import { Button } from "@/components/ui/button";
import { Logo } from "@/components/brand/logo";

const TRADES = ["Electricians", "Plumbers", "Builders", "Cleaners", "Freelancers", "Gardeners", "Decorators", "Consultants"];

const FEATURES = [
  { icon: Timer, title: "Your first invoice in 60 seconds", body: "Type your details once. Add a line, hit download. No accounting knowledge needed." },
  { icon: Calculator, title: "Penny-perfect maths", body: "Subtotals, discounts and VAT calculated exactly and rounded to two decimal places — every time." },
  { icon: BadgePoundSterling, title: "Built for UK VAT", body: "Switch VAT on or off. Mix 20%, 5% and 0% lines. Your VAT number and a VAT summary appear automatically." },
  { icon: FileDown, title: "Crisp PDF downloads", body: "Professional A4 PDFs ready to email, plus print-friendly layouts for paper copies." },
  { icon: LayoutTemplate, title: "Three polished templates", body: "Classic, Modern and Minimal designs, with your logo and business details." },
  { icon: Copy, title: "Save and duplicate", body: "Keep every invoice and copy last month's in one click — new number, new dates." },
  { icon: Smartphone, title: "Works on your phone", body: "Invoice from the van, the site or the sofa. Designed for small screens first." },
  { icon: ShieldCheck, title: "Private by design", body: "Your data is yours. Accounts use bank-grade security with every record locked to its owner." },
];

const FAQS = [
  {
    q: "Is InvoiceFlow really free?",
    a: "Yes. The Free plan lets you create up to 3 invoices a month with PDF downloads, forever, without a card. Upgrade to Pro for unlimited invoices when you need it.",
  },
  {
    q: "I'm not VAT registered. Can I still use it?",
    a: "Absolutely — most sole traders aren't. VAT is switched off by default unless you enter a VAT number. Only switch it on if you're registered with HMRC.",
  },
  {
    q: "What needs to be on a UK invoice?",
    a: "A unique invoice number, your business name and address, your customer's name and address, the invoice date, what you supplied, and the amount owed. Limited companies should also show their registered number and office. VAT-registered businesses must add their VAT number and the VAT breakdown. InvoiceFlow prompts you for each of these.",
  },
  {
    q: "Where are my invoices stored?",
    a: "Right now, invoices you save are kept privately in your own browser on this device. Secure cloud accounts — so you can sign in from anywhere — are coming next.",
  },
  {
    q: "Does InvoiceFlow work with Making Tax Digital?",
    a: "InvoiceFlow helps you create and keep invoice records, but it is not HMRC-recognised MTD software and doesn't submit returns. Keep using your MTD-compatible software or accountant for VAT and income tax submissions.",
  },
  {
    q: "Can I cancel a paid plan at any time?",
    a: "Yes. When paid plans launch you'll be able to cancel any time from your account, and you'll keep access until the end of the period you've paid for.",
  },
];

function HeroInvoiceMock() {
  const rows = [
    ["Kitchen rewire (labour)", "£540.00"],
    ["Materials & fittings", "£285.50"],
    ["EIC certificate", "£60.00"],
  ];
  return (
    <div className="relative mx-auto w-full max-w-md animate-float">
      <div className="absolute -inset-6 rounded-[2rem] bg-emerald-500/20 blur-3xl" aria-hidden />
      <div className="relative rounded-2xl bg-white p-6 text-navy-900 shadow-2xl shadow-black/40 ring-1 ring-white/10">
        <div className="flex items-start justify-between">
          <div>
            <p className="font-display text-lg font-extrabold">Spark & Co. Electrical</p>
            <p className="text-xs text-navy-400">Leeds · VAT GB 123 4567 89</p>
          </div>
          <div className="text-right">
            <p className="text-xs font-bold uppercase tracking-widest text-emerald-600">Invoice</p>
            <p className="font-mono text-sm">INV-0042</p>
          </div>
        </div>
        <div className="mt-6 space-y-2.5 text-sm">
          {rows.map(([d, a]) => (
            <div key={d} className="flex justify-between border-b border-dashed border-navy-100 pb-2.5">
              <span className="text-navy-600">{d}</span>
              <span className="font-medium tabular-nums">{a}</span>
            </div>
          ))}
        </div>
        <div className="mt-4 space-y-1 text-sm">
          <div className="flex justify-between text-navy-500"><span>Subtotal</span><span className="tabular-nums">£885.50</span></div>
          <div className="flex justify-between text-navy-500"><span>VAT 20%</span><span className="tabular-nums">£177.10</span></div>
        </div>
        <div className="mt-4 flex items-center justify-between rounded-xl bg-navy-900 px-4 py-3 text-white">
          <span className="text-sm font-semibold">Total due</span>
          <span className="font-display text-xl font-extrabold tabular-nums">£1,062.60</span>
        </div>
        <div className="absolute -right-4 -top-4 rotate-6 rounded-full bg-emerald-500 px-3 py-1.5 text-xs font-extrabold text-navy-950 shadow-lg">PAID ✓</div>
      </div>
      <p className="mt-4 text-center text-xs text-white/40">Illustration</p>
    </div>
  );
}

export default function HomePage() {
  return (
    <>
      <SiteHeader variant="dark" />
      <main>
        {/* Hero */}
        <section className="relative overflow-hidden bg-navy-950 pt-28 pb-20 text-white sm:pt-36 sm:pb-28">
          <div className="bg-grid absolute inset-0 [mask-image:radial-gradient(ellipse_at_top,black,transparent_70%)]" aria-hidden />
          <div className="absolute -top-40 right-0 h-[480px] w-[480px] rounded-full bg-emerald-500/20 blur-[120px]" aria-hidden />
          <div className="absolute -left-40 bottom-0 h-[400px] w-[400px] rounded-full bg-navy-500/30 blur-[120px]" aria-hidden />
          <div className="relative mx-auto grid max-w-7xl items-center gap-16 px-4 sm:px-6 lg:grid-cols-2">
            <div className="animate-fade-up">
              <span className="inline-flex items-center gap-2 rounded-full border border-emerald-400/30 bg-emerald-400/10 px-3 py-1 text-xs font-semibold text-emerald-300">
                <Sparkles className="h-3.5 w-3.5" /> Made for UK sole traders & small businesses
              </span>
              <h1 className="mt-6 font-display text-4xl font-extrabold leading-[1.05] tracking-tight sm:text-6xl">
                Create Professional Invoices <span className="bg-linear-to-r from-emerald-300 to-emerald-500 bg-clip-text text-transparent">in Seconds.</span>
              </h1>
              <p className="mt-6 max-w-xl text-lg leading-relaxed text-navy-200">
                Beautiful, VAT-ready invoices in pounds sterling. Add your logo, your items and your bank details — then download a polished PDF and get paid faster.
              </p>
              <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                <Button asChild size="lg">
                  <Link href="/create">
                    Create Your Free Invoice <ArrowRight />
                  </Link>
                </Button>
                <Button asChild size="lg" variant="ghostDark" className="border border-white/15">
                  <Link href="/create?sample=1">See a sample invoice</Link>
                </Button>
              </div>
              <p className="mt-5 text-sm text-navy-300">No card needed · No sign-up to try · GBP & UK dates by default</p>
            </div>
            <div className="animate-fade-up [animation-delay:150ms]">
              <HeroInvoiceMock />
            </div>
          </div>
        </section>

        {/* Trades strip */}
        <section className="border-b border-navy-100 bg-white py-8" aria-label="Who it's for">
          <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-center gap-x-8 gap-y-3 px-4 text-sm font-semibold text-navy-400">
            <span className="text-navy-600">Built for</span>
            {TRADES.map((t) => (
              <span key={t} className="transition hover:text-emerald-600">{t}</span>
            ))}
          </div>
        </section>

        {/* Features */}
        <section id="features" className="scroll-mt-20 py-24">
          <div className="mx-auto max-w-7xl px-4 sm:px-6">
            <div className="mx-auto max-w-2xl text-center">
              <p className="text-sm font-bold uppercase tracking-widest text-emerald-600">Features</p>
              <h2 className="mt-3 font-display text-3xl font-extrabold tracking-tight sm:text-4xl">Everything you need to get paid. Nothing you don&apos;t.</h2>
              <p className="mt-4 text-lg text-navy-500">Designed with tradespeople and freelancers who&apos;d rather be working than doing paperwork.</p>
            </div>
            <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
              {FEATURES.map(({ icon: Icon, title, body }) => (
                <div key={title} className="group rounded-2xl border border-navy-100 bg-white p-6 transition duration-300 hover:-translate-y-1 hover:border-emerald-200 hover:shadow-lg">
                  <div className="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-navy-900 text-emerald-400 transition group-hover:bg-emerald-500 group-hover:text-navy-950">
                    <Icon className="h-5 w-5" />
                  </div>
                  <h3 className="mt-5 font-display font-bold">{title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-navy-500">{body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* How it works */}
        <section className="bg-navy-950 py-24 text-white">
          <div className="mx-auto max-w-7xl px-4 sm:px-6">
            <h2 className="text-center font-display text-3xl font-extrabold tracking-tight sm:text-4xl">Three steps. About a minute.</h2>
            <div className="mt-14 grid gap-6 md:grid-cols-3">
              {[
                { icon: Building2, t: "Add your details", b: "Business name, address and logo. We remember them for next time." },
                { icon: Users, t: "Add your customer & work", b: "Who it's for and what you did. Totals and VAT update live as you type." },
                { icon: FileDown, t: "Download & send", b: "Pick a template, download the PDF and email it. Mark it paid when the money lands." },
              ].map(({ icon: Icon, t, b }, i) => (
                <div key={t} className="relative rounded-2xl border border-white/10 bg-white/[0.03] p-7">
                  <span className="font-display text-5xl font-extrabold text-white/10">0{i + 1}</span>
                  <Icon className="mt-4 h-6 w-6 text-emerald-400" />
                  <h3 className="mt-3 font-display text-lg font-bold">{t}</h3>
                  <p className="mt-2 text-sm text-navy-200">{b}</p>
                </div>
              ))}
            </div>
            <div className="mt-12 text-center">
              <Button asChild size="lg">
                <Link href="/create">Create Your Free Invoice <ArrowRight /></Link>
              </Button>
            </div>
          </div>
        </section>

        <Pricing />

        {/* FAQ */}
        <section id="faq" className="scroll-mt-20 py-24">
          <div className="mx-auto max-w-3xl px-4 sm:px-6">
            <h2 className="text-center font-display text-3xl font-extrabold tracking-tight sm:text-4xl">Questions, answered</h2>
            <div className="mt-12 divide-y divide-navy-100 rounded-2xl border border-navy-100">
              {FAQS.map((f) => (
                <details key={f.q} className="group px-6 py-5 [&_summary::-webkit-details-marker]:hidden">
                  <summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-display font-bold text-navy-900">
                    {f.q}
                    <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-navy-50 text-navy-500 transition group-open:rotate-45 group-open:bg-emerald-100 group-open:text-emerald-700">+</span>
                  </summary>
                  <p className="mt-3 text-sm leading-relaxed text-navy-600">{f.a}</p>
                </details>
              ))}
            </div>
          </div>
        </section>

        {/* Final CTA */}
        <section className="px-4 pb-24 sm:px-6">
          <div className="relative mx-auto max-w-5xl overflow-hidden rounded-3xl bg-linear-to-br from-navy-900 to-navy-950 px-6 py-16 text-center text-white sm:px-16">
            <div className="absolute -right-20 -top-20 h-72 w-72 rounded-full bg-emerald-500/25 blur-3xl" aria-hidden />
            <Logo dark className="relative justify-center" />
            <h2 className="relative mt-6 font-display text-3xl font-extrabold tracking-tight sm:text-4xl">Your next invoice could be done before the kettle boils.</h2>
            <div className="relative mt-8">
              <Button asChild size="lg">
                <Link href="/create">Start Free <ArrowRight /></Link>
              </Button>
            </div>
          </div>
        </section>
      </main>
      <SiteFooter />
    </>
  );
}
