import Link from "next/link";
import { Logo } from "@/components/brand/logo";
import { Button } from "@/components/ui/button";

export default function NotFound() {
  return (
    <main className="flex min-h-dvh flex-col items-center justify-center gap-6 bg-navy-950 p-6 text-center text-white">
      <Logo dark />
      <h1 className="font-display text-4xl font-extrabold">Page not found</h1>
      <p className="max-w-md text-navy-200">The page you&apos;re looking for doesn&apos;t exist or has moved.</p>
      <div className="flex gap-2">
        <Button asChild><Link href="/create">Create an invoice</Link></Button>
        <Button asChild variant="ghostDark" className="border border-white/15"><Link href="/">Home</Link></Button>
      </div>
    </main>
  );
}
