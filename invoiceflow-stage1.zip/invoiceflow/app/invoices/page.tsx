"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { AlertTriangle, Copy, FileDown, FilePlus2, Info, Loader2, Pencil, Search, Trash2 } from "lucide-react";
import type { DisplayStatus, Invoice, InvoiceStatus } from "@/lib/invoice/types";
import { calculateTotals } from "@/lib/invoice/calculations";
import { formatDateUK, formatPence } from "@/lib/invoice/format";
import { deleteInvoice, displayStatus, listInvoices, setStatus } from "@/lib/invoice/storage";
import { SiteHeader } from "@/components/landing/site-header";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input, Select } from "@/components/ui/input";
import { PageLoader } from "@/components/ui/page-loader";
import { downloadInvoicePdf } from "@/components/invoice/download-pdf";
import { cn } from "@/lib/utils";

const FILTERS: { id: "all" | DisplayStatus; label: string }[] = [
  { id: "all", label: "All" },
  { id: "draft", label: "Draft" },
  { id: "unpaid", label: "Unpaid" },
  { id: "overdue", label: "Overdue" },
  { id: "paid", label: "Paid" },
];

const STATUS_LABEL: Record<DisplayStatus, string> = { draft: "Draft", unpaid: "Unpaid", overdue: "Overdue", paid: "Paid" };

export default function InvoicesPage() {
  const [invoices, setInvoices] = useState<Invoice[] | null>(null);
  const [filter, setFilter] = useState<"all" | DisplayStatus>("all");
  const [query, setQuery] = useState("");
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [error, setError] = useState("");

  const refresh = () => setInvoices(listInvoices());
  useEffect(refresh, []);

  const rows = useMemo(
    () => (invoices ?? []).map((inv) => ({ inv, totals: calculateTotals(inv), status: displayStatus(inv) })),
    [invoices]
  );

  const summary = useMemo(() => {
    const sent = rows.filter((r) => r.status !== "draft");
    const sum = (list: typeof rows) => list.reduce((a, r) => a + r.totals.totalPence, 0);
    return {
      invoiced: sum(sent),
      paid: sum(sent.filter((r) => r.status === "paid")),
      outstanding: sum(sent.filter((r) => r.status === "unpaid" || r.status === "overdue")),
      overdue: sum(sent.filter((r) => r.status === "overdue")),
      overdueCount: sent.filter((r) => r.status === "overdue").length,
    };
  }, [rows]);

  const visible = rows.filter((r) => {
    if (filter !== "all" && r.status !== filter) return false;
    const q = query.trim().toLowerCase();
    return !q || r.inv.number.toLowerCase().includes(q) || r.inv.customer.name.toLowerCase().includes(q);
  });

  async function download(inv: Invoice) {
    setBusyId(inv.id);
    setError("");
    try {
      await downloadInvoicePdf(inv, calculateTotals(inv));
    } catch {
      setError("We couldn't create that PDF. Open the invoice and try again.");
    } finally {
      setBusyId(null);
    }
  }

  if (invoices === null) return <PageLoader label="Loading your invoices…" />;

  return (
    <>
      <SiteHeader variant="light" />
      <main className="min-h-dvh bg-navy-50/60">
        <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <h1 className="font-display text-3xl font-extrabold tracking-tight">My invoices</h1>
              <p className="mt-1 text-sm text-navy-500">Track what you&apos;ve sent and what you&apos;re owed.</p>
            </div>
            <Button asChild size="lg"><Link href="/create"><FilePlus2 /> New invoice</Link></Button>
          </div>

          <div className="mt-5 flex items-start gap-3 rounded-xl border border-navy-100 bg-white p-4 text-sm text-navy-600">
            <Info className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" />
            <p>Invoices are currently saved privately <strong>in this browser on this device</strong>. Secure accounts with cloud backup are coming soon — until then, download a PDF of anything important.</p>
          </div>

          <div className="mt-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
            {[
              { label: "Total invoiced", value: summary.invoiced, tone: "text-navy-900" },
              { label: "Paid", value: summary.paid, tone: "text-emerald-600" },
              { label: "Outstanding", value: summary.outstanding, tone: "text-amber-600" },
              { label: `Overdue${summary.overdueCount ? ` (${summary.overdueCount})` : ""}`, value: summary.overdue, tone: "text-red-600" },
            ].map((c) => (
              <div key={c.label} className="rounded-2xl border border-navy-100 bg-white p-5 shadow-sm">
                <p className="text-xs font-semibold uppercase tracking-wider text-navy-400">{c.label}</p>
                <p className={cn("mt-2 font-display text-2xl font-extrabold tabular-nums", c.tone)}>{formatPence(c.value)}</p>
              </div>
            ))}
          </div>

          {rows.length === 0 ? (
            <div className="mt-8 flex flex-col items-center rounded-3xl border border-dashed border-navy-200 bg-white px-6 py-16 text-center">
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-navy-900 text-emerald-400"><FilePlus2 className="h-6 w-6" /></div>
              <h2 className="mt-5 font-display text-xl font-bold">No invoices yet</h2>
              <p className="mt-2 max-w-sm text-sm text-navy-500">Create your first invoice in about a minute. Not sure where to start? Take a look at the sample.</p>
              <div className="mt-6 flex flex-wrap justify-center gap-2">
                <Button asChild><Link href="/create">Create Your Free Invoice</Link></Button>
                <Button asChild variant="outline"><Link href="/create?sample=1">View sample invoice</Link></Button>
              </div>
            </div>
          ) : (
            <div className="mt-8 rounded-2xl border border-navy-100 bg-white shadow-sm">
              <div className="flex flex-col gap-3 border-b border-navy-100 p-4 md:flex-row md:items-center md:justify-between">
                <div className="flex gap-1 overflow-x-auto" role="tablist" aria-label="Filter by status">
                  {FILTERS.map((f) => (
                    <button
                      key={f.id}
                      role="tab"
                      aria-selected={filter === f.id}
                      onClick={() => setFilter(f.id)}
                      className={cn("whitespace-nowrap rounded-lg px-3 py-1.5 text-sm font-semibold transition", filter === f.id ? "bg-navy-900 text-white" : "text-navy-500 hover:bg-navy-50")}
                    >
                      {f.label}
                    </button>
                  ))}
                </div>
                <div className="relative md:w-72">
                  <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-navy-300" />
                  <Input aria-label="Search invoices" placeholder="Search customer or invoice no." className="pl-9" value={query} onChange={(e) => setQuery(e.target.value)} />
                </div>
              </div>
              {error && <p className="flex items-center gap-2 border-b border-red-100 bg-red-50 px-4 py-2 text-sm text-red-700" role="alert"><AlertTriangle className="h-4 w-4" />{error}</p>}

              {visible.length === 0 ? (
                <p className="px-4 py-12 text-center text-sm text-navy-500">No invoices match. Try a different search or filter.</p>
              ) : (
                <ul className="divide-y divide-navy-50">
                  {visible.map(({ inv, totals, status }) => (
                    <li key={inv.id} className="grid gap-3 p-4 transition hover:bg-navy-50/50 md:grid-cols-[1.2fr_1fr_auto_auto_auto] md:items-center md:gap-6">
                      <div className="min-w-0">
                        <Link href={`/create?id=${inv.id}`} className="font-semibold text-navy-900 hover:text-emerald-700">{inv.customer.name || "No customer yet"}</Link>
                        <p className="font-mono text-xs text-navy-400">{inv.number}</p>
                      </div>
                      <div className="text-xs text-navy-500">
                        <p>Issued {formatDateUK(inv.issueDate)}</p>
                        <p className={cn(status === "overdue" && "font-semibold text-red-600")}>Due {inv.paymentTermsDays === 0 ? "on receipt" : formatDateUK(inv.dueDate)}</p>
                      </div>
                      <p className="font-display text-lg font-bold tabular-nums md:text-right">{formatPence(totals.totalPence)}</p>
                      <div className="flex items-center gap-2">
                        <Badge variant={status}>{STATUS_LABEL[status]}</Badge>
                        <Select
                          aria-label={`Change status of ${inv.number}`}
                          className="h-8 w-auto text-xs"
                          value={inv.status}
                          onChange={(e) => { setStatus(inv.id, e.target.value as InvoiceStatus); refresh(); }}
                        >
                          <option value="draft">Draft</option>
                          <option value="unpaid">Sent / unpaid</option>
                          <option value="paid">Paid</option>
                        </Select>
                      </div>
                      <div className="flex items-center gap-1 md:justify-end">
                        <Button asChild variant="ghost" size="icon" aria-label={`Edit ${inv.number}`}><Link href={`/create?id=${inv.id}`}><Pencil /></Link></Button>
                        <Button asChild variant="ghost" size="icon" aria-label={`Duplicate ${inv.number}`}><Link href={`/create?from=${inv.id}`}><Copy /></Link></Button>
                        <Button variant="ghost" size="icon" aria-label={`Download ${inv.number} as PDF`} onClick={() => download(inv)} disabled={busyId === inv.id}>
                          {busyId === inv.id ? <Loader2 className="animate-spin" /> : <FileDown />}
                        </Button>
                        {confirmDelete === inv.id ? (
                          <span className="flex items-center gap-1">
                            <Button variant="destructive" size="sm" onClick={() => { deleteInvoice(inv.id); setConfirmDelete(null); refresh(); }}>Delete</Button>
                            <Button variant="ghost" size="sm" onClick={() => setConfirmDelete(null)}>Cancel</Button>
                          </span>
                        ) : (
                          <Button variant="ghost" size="icon" aria-label={`Delete ${inv.number}`} className="hover:bg-red-50 hover:text-red-600" onClick={() => setConfirmDelete(inv.id)}><Trash2 /></Button>
                        )}
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          )}
        </div>
      </main>
    </>
  );
}
