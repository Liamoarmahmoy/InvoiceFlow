import type { Metadata, Viewport } from "next";
import { Inter, Plus_Jakarta_Sans } from "next/font/google";
import "./globals.css";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter", display: "swap" });
const jakarta = Plus_Jakarta_Sans({ subsets: ["latin"], variable: "--font-jakarta", weight: ["600", "700", "800"], display: "swap" });

export const metadata: Metadata = {
  title: { default: "InvoiceFlow — Professional invoices in seconds", template: "%s · InvoiceFlow" },
  description:
    "Free invoice generator for UK sole traders, freelancers and tradespeople. GBP, VAT-ready, PDF download. Create your first invoice in under a minute.",
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000"),
  openGraph: { title: "InvoiceFlow", description: "Create professional invoices in seconds.", locale: "en_GB", type: "website" },
};

export const viewport: Viewport = { themeColor: "#0b1630", width: "device-width", initialScale: 1 };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en-GB" className={`${inter.variable} ${jakarta.variable}`}>
      <body className="min-h-dvh font-sans">{children}</body>
    </html>
  );
}
