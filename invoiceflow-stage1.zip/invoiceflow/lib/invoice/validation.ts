import type { Invoice } from "./types";
import { numberError } from "./calculations";

export type Errors = Record<string, string>;

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
// UK VAT numbers: GB + 9 digits (or 12 for branch traders), or GBGD/GBHA + 3 digits.
const VAT = /^(GB)?(\d{9}|\d{12}|GD\d{3}|HA\d{3})$/i;
// Companies House: 8 characters, digits or a 2-letter prefix (e.g. SC123456).
const COMPANY = /^([A-Z]{2}\d{6}|\d{8})$/i;
const POSTCODE = /^[A-Z]{1,2}\d[A-Z\d]?\s*\d[A-Z]{2}$/i;

/**
 * Checks everything needed before an invoice can be marked as sent/downloaded.
 * Drafts can be saved with gaps; this is used for the "Download PDF" and
 * "Mark as sent" actions so customers never receive an incomplete invoice.
 */
export function validateInvoice(inv: Invoice): Errors {
  const e: Errors = {};
  if (!inv.number.trim()) e.number = "Give the invoice a number";
  if (!inv.business.name.trim()) e["business.name"] = "Add your business or trading name";
  if (inv.business.email && !EMAIL.test(inv.business.email.trim())) e["business.email"] = "That email address doesn't look right";
  if (inv.business.address.postcode && !POSTCODE.test(inv.business.address.postcode.trim()) && inv.business.address.country === "United Kingdom")
    e["business.address.postcode"] = "Enter a UK postcode, like LS1 1AA";
  if (inv.business.companyNumber && !COMPANY.test(inv.business.companyNumber.replace(/\s/g, "")))
    e["business.companyNumber"] = "Company numbers are 8 characters, like 01234567 or SC123456";
  if (inv.vatEnabled) {
    if (!inv.business.vatNumber.trim()) e["business.vatNumber"] = "VAT invoices must show your VAT registration number";
    else if (!VAT.test(inv.business.vatNumber.replace(/\s/g, ""))) e["business.vatNumber"] = "UK VAT numbers look like GB123456789";
    if (!inv.business.address.line1.trim()) e["business.address.line1"] = "VAT invoices must show your business address";
    if (!inv.customer.address.line1.trim()) e["customer.address.line1"] = "VAT invoices must show your customer's address";
  }
  if (!inv.customer.name.trim()) e["customer.name"] = "Who is this invoice for?";
  if (inv.customer.email && !EMAIL.test(inv.customer.email.trim())) e["customer.email"] = "That email address doesn't look right";
  if (!inv.issueDate) e.issueDate = "Choose the invoice date";
  if (inv.dueDate && inv.issueDate && inv.dueDate < inv.issueDate) e.dueDate = "The due date can't be before the invoice date";

  const realItems = inv.items.filter((it) => it.description.trim() || it.unitPrice.trim());
  if (realItems.length === 0) e.items = "Add at least one item or service";
  inv.items.forEach((it, i) => {
    const hasContent = it.description.trim() || it.unitPrice.trim();
    if (!hasContent) return;
    if (!it.description.trim()) e[`items.${i}.description`] = "Describe this item";
    const q = numberError(it.quantity, { label: "Quantity", scale: 3, max: 1_000_000 });
    if (q) e[`items.${i}.quantity`] = q;
    const p = numberError(it.unitPrice, { label: "Price", max: 10_000_000 });
    if (p) e[`items.${i}.unitPrice`] = p;
    if (inv.vatEnabled) {
      const v = numberError(it.vatRate, { label: "VAT rate", max: 100 });
      if (v) e[`items.${i}.vatRate`] = v;
    }
  });

  if (inv.discountType !== "none") {
    const d = numberError(inv.discountValue, { label: "Discount", max: inv.discountType === "percent" ? 100 : 10_000_000 });
    if (d) e.discountValue = d;
  }
  if (inv.bank.sortCode && inv.bank.sortCode.replace(/\D/g, "").length !== 6) e["bank.sortCode"] = "Sort codes have 6 digits, like 12-34-56";
  if (inv.bank.accountNumber && !/^\d{8}$/.test(inv.bank.accountNumber.replace(/\s/g, "")))
    e["bank.accountNumber"] = "UK account numbers have 8 digits";
  return e;
}
