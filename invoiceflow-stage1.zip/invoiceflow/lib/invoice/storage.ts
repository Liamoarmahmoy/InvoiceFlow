// STAGE 1 STORAGE: invoices are saved in this browser (localStorage).
// They are private to this device and are NOT backed up. In Stage 3 this file
// is replaced by Supabase, with Row Level Security so each user only sees
// their own data. The function names stay the same so the UI barely changes.

import type { BankDetails, BusinessDetails, DisplayStatus, Invoice } from "./types";
import { todayISO } from "./format";

const KEYS = {
  invoices: "invoiceflow.v1.invoices",
  business: "invoiceflow.v1.business",
  bank: "invoiceflow.v1.bank",
  counter: "invoiceflow.v1.counter",
  onboarded: "invoiceflow.v1.onboarded",
};

const isBrowser = () => typeof window !== "undefined" && !!window.localStorage;

function read<T>(key: string, fallback: T): T {
  if (!isBrowser()) return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

export class StorageError extends Error {}

function write(key: string, value: unknown) {
  if (!isBrowser()) return;
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch {
    throw new StorageError(
      "Your browser's storage is full. Try removing your logo or deleting old invoices, then save again."
    );
  }
}

export function listInvoices(): Invoice[] {
  return read<Invoice[]>(KEYS.invoices, []).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
}

export function getInvoice(id: string): Invoice | undefined {
  return listInvoices().find((i) => i.id === id);
}

export function saveInvoice(invoice: Invoice): Invoice {
  const all = read<Invoice[]>(KEYS.invoices, []);
  const clash = all.find((i) => i.number.trim().toLowerCase() === invoice.number.trim().toLowerCase() && i.id !== invoice.id);
  if (clash) throw new StorageError(`Invoice number ${invoice.number} is already used. Each invoice needs a unique number.`);
  const updated = { ...invoice, updatedAt: new Date().toISOString() };
  const next = all.some((i) => i.id === invoice.id) ? all.map((i) => (i.id === invoice.id ? updated : i)) : [...all, updated];
  write(KEYS.invoices, next);
  bumpCounterFrom(invoice.number);
  return updated;
}

export function deleteInvoice(id: string) {
  write(KEYS.invoices, read<Invoice[]>(KEYS.invoices, []).filter((i) => i.id !== id));
}

export function setStatus(id: string, status: Invoice["status"]) {
  const all = read<Invoice[]>(KEYS.invoices, []);
  write(KEYS.invoices, all.map((i) => (i.id === id ? { ...i, status, updatedAt: new Date().toISOString() } : i)));
}

// ---- Business profile (remembered so users don't retype it) ----
export const loadBusiness = () => read<BusinessDetails | null>(KEYS.business, null);
export const saveBusiness = (b: BusinessDetails) => write(KEYS.business, b);
export const loadBank = () => read<BankDetails | null>(KEYS.bank, null);
export const saveBank = (b: BankDetails) => write(KEYS.bank, b);

export const isOnboarded = () => read<boolean>(KEYS.onboarded, false);
export const setOnboarded = () => write(KEYS.onboarded, true);

// ---- Automatic, unique invoice numbering: INV-0001, INV-0002, ... ----
function trailingNumber(num: string): number {
  const m = num.match(/(\d+)\s*$/);
  return m ? Number(m[1]) : 0;
}

function bumpCounterFrom(num: string) {
  const n = trailingNumber(num);
  if (n > read<number>(KEYS.counter, 0)) write(KEYS.counter, n);
}

export function nextInvoiceNumber(prefix = "INV-"): string {
  const used = new Set(read<Invoice[]>(KEYS.invoices, []).map((i) => i.number.trim().toLowerCase()));
  let n = Math.max(read<number>(KEYS.counter, 0), ...listInvoices().map((i) => trailingNumber(i.number)), 0) + 1;
  let candidate = `${prefix}${String(n).padStart(4, "0")}`;
  while (used.has(candidate.toLowerCase())) {
    n += 1;
    candidate = `${prefix}${String(n).padStart(4, "0")}`;
  }
  return candidate;
}

/** Unpaid invoices past their due date are shown as overdue automatically. */
export function displayStatus(inv: Pick<Invoice, "status" | "dueDate">): DisplayStatus {
  if (inv.status === "unpaid" && inv.dueDate && inv.dueDate < todayISO()) return "overdue";
  return inv.status;
}
