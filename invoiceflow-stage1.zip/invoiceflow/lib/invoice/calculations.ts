// InvoiceFlow calculation engine.
//
// Every amount is handled as an INTEGER number of pennies. Quantities are held
// to 3 decimal places (thousandths) and VAT/discount rates to 2 decimal places
// (basis points, where 20% = 2000). Integer maths is exact, so £0.10 + £0.20 is
// always £0.30 — no floating-point surprises. Rounding is "half up" (0.5p
// rounds away from zero) to the nearest penny, which is what HMRC accepts.
//
// This file deliberately has no imports except types, so it can be unit
// tested directly with Node (see calculations.test.ts).

import type { DiscountType } from "./types";

export interface CalcLine {
  quantity: string;
  unitPrice: string;
  vatRate: string;
}

export interface CalcInput {
  items: CalcLine[];
  vatEnabled: boolean;
  discountType: DiscountType;
  discountValue: string;
}

export interface VatBand {
  rateBp: number; // basis points, 2000 = 20%
  netPence: number; // net after discount in this band
  vatPence: number;
}

export interface Totals {
  lineTotalsPence: number[]; // per line, before discount (NaN-free; invalid lines = 0)
  subtotalPence: number;
  discountPence: number;
  netPence: number; // subtotal - discount
  vatBands: VatBand[];
  vatPence: number;
  totalPence: number;
}

/**
 * Parse a decimal string into an integer scaled by 10^scale, rounding half up.
 * Returns null for anything that is not a plain non-negative number.
 * parseScaled("12.345", 2) === 1235
 */
export function parseScaled(input: string, scale: number): number | null {
  const s = String(input ?? "").trim().replace(/,/g, "").replace(/^£/, "");
  if (s === "") return 0;
  if (!/^\d*\.?\d*$/.test(s) || s === ".") return null;
  const [whole = "", frac = ""] = s.split(".");
  const padded = (frac + "0".repeat(scale + 1)).slice(0, scale + 1);
  const base = Number((whole || "0") + padded.slice(0, scale));
  const roundDigit = Number(padded[scale]);
  const value = base + (roundDigit >= 5 ? 1 : 0);
  return Number.isSafeInteger(value) ? value : null;
}

/** Integer division rounding half away from zero. Exact for safe integers. */
export function roundDiv(numerator: number, denominator: number): number {
  if (denominator === 0) return 0;
  const sign = Math.sign(numerator) * Math.sign(denominator);
  const n = Math.abs(numerator);
  const d = Math.abs(denominator);
  const q = Math.floor((2 * n + d) / (2 * d));
  return sign * q || 0;
}

export const toPence = (v: string) => parseScaled(v, 2);
export const toMilli = (v: string) => parseScaled(v, 3);
export const toBasisPoints = (v: string) => parseScaled(v, 2);

/** Line total in pence = quantity × unit price, rounded to the penny. */
export function lineTotalPence(quantity: string, unitPrice: string): number {
  const q = toMilli(quantity);
  const p = toPence(unitPrice);
  if (q === null || p === null) return 0;
  return roundDiv(q * p, 1000);
}

/**
 * Split `amount` across `weights` in proportion, so the parts always add up
 * to exactly `amount` (largest-remainder method). Used to spread a whole-invoice
 * discount across VAT bands.
 */
export function allocate(amount: number, weights: number[]): number[] {
  const total = weights.reduce((a, b) => a + b, 0);
  if (total <= 0 || amount <= 0) return weights.map(() => 0);
  const raw = weights.map((w) => (amount * w) / total);
  const parts = raw.map(Math.floor);
  let remainder = amount - parts.reduce((a, b) => a + b, 0);
  const order = raw
    .map((r, i) => ({ i, frac: r - Math.floor(r) }))
    .sort((a, b) => b.frac - a.frac || a.i - b.i);
  for (const { i } of order) {
    if (remainder <= 0) break;
    parts[i] += 1;
    remainder -= 1;
  }
  return parts;
}

export function calculateTotals(input: CalcInput): Totals {
  const lineTotalsPence = input.items.map((it) => lineTotalPence(it.quantity, it.unitPrice));
  const subtotalPence = lineTotalsPence.reduce((a, b) => a + b, 0);

  // Discount (applied to the subtotal, before VAT).
  let discountPence = 0;
  if (input.discountType === "percent") {
    const bp = Math.min(toBasisPoints(input.discountValue) ?? 0, 10000);
    discountPence = roundDiv(subtotalPence * bp, 10000);
  } else if (input.discountType === "fixed") {
    discountPence = Math.min(toPence(input.discountValue) ?? 0, subtotalPence);
  }
  const netPence = subtotalPence - discountPence;

  // VAT, grouped by rate so mixed-rate invoices (e.g. 20% and 5%) are correct.
  let vatBands: VatBand[] = [];
  if (input.vatEnabled) {
    const byRate = new Map<number, number>();
    input.items.forEach((it, i) => {
      const rate = Math.min(toBasisPoints(it.vatRate) ?? 0, 10000);
      byRate.set(rate, (byRate.get(rate) ?? 0) + lineTotalsPence[i]);
    });
    const rates = [...byRate.keys()].sort((a, b) => b - a);
    const grossByRate = rates.map((r) => byRate.get(r) ?? 0);
    const discountShares = allocate(discountPence, grossByRate);
    vatBands = rates.map((rateBp, i) => {
      const bandNet = grossByRate[i] - discountShares[i];
      return { rateBp, netPence: bandNet, vatPence: roundDiv(bandNet * rateBp, 10000) };
    });
  }
  const vatPence = vatBands.reduce((a, b) => a + b.vatPence, 0);

  return {
    lineTotalsPence,
    subtotalPence,
    discountPence,
    netPence,
    vatBands,
    vatPence,
    totalPence: netPence + vatPence,
  };
}

/** Validate a single numeric field. Returns an error message or null. */
export function numberError(value: string, opts: { label: string; max?: number; scale?: number }): string | null {
  const parsed = parseScaled(value, opts.scale ?? 2);
  if (parsed === null) return `${opts.label} must be a number, like 12.50`;
  if (opts.max !== undefined && parsed > opts.max * 10 ** (opts.scale ?? 2)) {
    return `${opts.label} can't be more than ${opts.max}`;
  }
  return null;
}
