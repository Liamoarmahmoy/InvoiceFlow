// Core data shapes for an invoice. Numbers typed by the user are kept as
// strings (exactly what is in the input box) and converted to whole pennies
// only inside calculations.ts — this avoids floating-point rounding errors.

export type InvoiceStatus = "draft" | "unpaid" | "paid";
export type DisplayStatus = InvoiceStatus | "overdue";
export type TemplateId = "classic" | "modern" | "minimal";
export type DiscountType = "none" | "percent" | "fixed";

export interface Address {
  line1: string;
  line2: string;
  town: string;
  county: string;
  postcode: string;
  country: string;
}

export interface BusinessDetails {
  name: string;
  address: Address;
  email: string;
  phone: string;
  website: string;
  logoDataUrl: string; // PNG/JPEG as a data URL ("" when none)
  companyNumber: string; // optional Companies House number
  vatNumber: string; // optional VAT registration number
}

export interface CustomerDetails {
  name: string;
  contactName: string;
  address: Address;
  email: string;
  phone: string;
}

export interface BankDetails {
  accountName: string;
  bankName: string;
  sortCode: string;
  accountNumber: string;
  iban: string;
}

export interface LineItem {
  id: string;
  description: string;
  quantity: string;
  unitPrice: string;
  vatRate: string; // percentage, e.g. "20", "5", "0"
}

export interface Invoice {
  id: string;
  number: string;
  status: InvoiceStatus;
  template: TemplateId;
  issueDate: string; // yyyy-mm-dd
  supplyDate: string; // optional tax point if different from issue date
  dueDate: string; // yyyy-mm-dd
  paymentTermsDays: number;
  business: BusinessDetails;
  customer: CustomerDetails;
  items: LineItem[];
  vatEnabled: boolean;
  defaultVatRate: string;
  discountType: DiscountType;
  discountValue: string;
  bank: BankDetails;
  notes: string;
  terms: string;
  createdAt: string;
  updatedAt: string;
  isSample?: boolean;
}
