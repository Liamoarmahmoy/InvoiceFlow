import type { Address, BankDetails, BusinessDetails, Invoice, LineItem } from "./types";
import { addDaysISO, todayISO } from "./format";

export const uid = () =>
  typeof crypto !== "undefined" && "randomUUID" in crypto
    ? crypto.randomUUID()
    : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;

export const emptyAddress = (): Address => ({ line1: "", line2: "", town: "", county: "", postcode: "", country: "United Kingdom" });

export const emptyBusiness = (): BusinessDetails => ({
  name: "",
  address: emptyAddress(),
  email: "",
  phone: "",
  website: "",
  logoDataUrl: "",
  companyNumber: "",
  vatNumber: "",
});

export const emptyBank = (): BankDetails => ({ accountName: "", bankName: "", sortCode: "", accountNumber: "", iban: "" });

export const newLineItem = (vatRate = "20"): LineItem => ({ id: uid(), description: "", quantity: "1", unitPrice: "", vatRate });

export const PAYMENT_TERM_OPTIONS = [
  { days: 0, label: "Due on receipt" },
  { days: 7, label: "7 days" },
  { days: 14, label: "14 days" },
  { days: 30, label: "30 days" },
  { days: 60, label: "60 days" },
];

export const VAT_RATE_OPTIONS = [
  { value: "20", label: "20% Standard" },
  { value: "5", label: "5% Reduced" },
  { value: "0", label: "0% Zero-rated" },
];

export function defaultTerms(days: number): string {
  return days === 0
    ? "Payment is due on receipt of this invoice."
    : `Payment is due within ${days} days of the invoice date. Please quote the invoice number as your payment reference.`;
}

export function blankInvoice(number: string, business?: BusinessDetails, bank?: BankDetails): Invoice {
  const issue = todayISO();
  const now = new Date().toISOString();
  return {
    id: uid(),
    number,
    status: "draft",
    template: "classic",
    issueDate: issue,
    supplyDate: "",
    dueDate: addDaysISO(issue, 14),
    paymentTermsDays: 14,
    business: business ?? emptyBusiness(),
    customer: { name: "", contactName: "", address: emptyAddress(), email: "", phone: "" },
    items: [newLineItem()],
    vatEnabled: Boolean(business?.vatNumber),
    defaultVatRate: "20",
    discountType: "none",
    discountValue: "",
    bank: bank ?? emptyBank(),
    notes: "Thank you for your business.",
    terms: defaultTerms(14),
    createdAt: now,
    updatedAt: now,
  };
}

/** A clearly-labelled demo invoice so new users can see a finished example. */
export function sampleInvoice(number: string): Invoice {
  const inv = blankInvoice(number);
  return {
    ...inv,
    isSample: true,
    template: "modern",
    business: {
      name: "Example Electrical Ltd (sample)",
      address: { line1: "12 Sample Street", line2: "", town: "Leeds", county: "West Yorkshire", postcode: "LS1 1AA", country: "United Kingdom" },
      email: "hello@example.com",
      phone: "0113 000 0000",
      website: "",
      logoDataUrl: "",
      companyNumber: "00000000",
      vatNumber: "GB000000000",
    },
    customer: {
      name: "Sample Customer",
      contactName: "A. Customer",
      address: { line1: "1 Example Road", line2: "", town: "Harrogate", county: "", postcode: "HG1 1AA", country: "United Kingdom" },
      email: "customer@example.com",
      phone: "",
    },
    items: [
      { id: uid(), description: "Consumer unit replacement (labour)", quantity: "6", unitPrice: "45.00", vatRate: "20" },
      { id: uid(), description: "18th Edition consumer unit + RCBOs", quantity: "1", unitPrice: "285.50", vatRate: "20" },
      { id: uid(), description: "Electrical Installation Certificate", quantity: "1", unitPrice: "60.00", vatRate: "20" },
    ],
    vatEnabled: true,
    discountType: "percent",
    discountValue: "5",
    bank: { accountName: "Example Electrical Ltd", bankName: "Example Bank", sortCode: "00-00-00", accountNumber: "00000000", iban: "" },
    notes: "This is a sample invoice using made-up details. Replace everything with your own information.",
  };
}
