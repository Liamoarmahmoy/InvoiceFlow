// Run with: npm test
// Uses Node's built-in test runner — no extra packages needed.
import { test } from "node:test";
import assert from "node:assert/strict";
import { allocate, calculateTotals, lineTotalPence, parseScaled, roundDiv } from "./calculations.ts";

const line = (quantity: string, unitPrice: string, vatRate = "20") => ({ quantity, unitPrice, vatRate });

test("parses money strings exactly", () => {
  assert.equal(parseScaled("12.5", 2), 1250);
  assert.equal(parseScaled("0.1", 2), 10);
  assert.equal(parseScaled("£1,250.99", 2), 125099);
  assert.equal(parseScaled("1.005", 2), 101); // half up
  assert.equal(parseScaled("1.004", 2), 100);
  assert.equal(parseScaled("", 2), 0);
  assert.equal(parseScaled("abc", 2), null);
  assert.equal(parseScaled("-5", 2), null);
  assert.equal(parseScaled("1.2.3", 2), null);
});

test("roundDiv rounds half up", () => {
  assert.equal(roundDiv(5, 10), 1);
  assert.equal(roundDiv(4, 10), 0);
  assert.equal(roundDiv(15, 10), 2);
  assert.equal(roundDiv(-15, 10), -2);
});

test("classic floating point trap: 0.1 + 0.2", () => {
  const t = calculateTotals({ items: [line("1", "0.1"), line("1", "0.2")], vatEnabled: false, discountType: "none", discountValue: "" });
  assert.equal(t.subtotalPence, 30);
  assert.equal(t.totalPence, 30);
});

test("line totals with fractional quantities", () => {
  assert.equal(lineTotalPence("1.5", "45"), 6750); // 1.5 hours at £45
  assert.equal(lineTotalPence("3", "19.99"), 5997);
  assert.equal(lineTotalPence("0.333", "10"), 333);
  assert.equal(lineTotalPence("2.5", "0.03"), 8); // 7.5p -> 8p
});

test("VAT at 20% on £100 net", () => {
  const t = calculateTotals({ items: [line("1", "100")], vatEnabled: true, discountType: "none", discountValue: "" });
  assert.equal(t.vatPence, 2000);
  assert.equal(t.totalPence, 12000);
});

test("VAT disabled ignores line rates", () => {
  const t = calculateTotals({ items: [line("1", "100")], vatEnabled: false, discountType: "none", discountValue: "" });
  assert.equal(t.vatPence, 0);
  assert.equal(t.vatBands.length, 0);
  assert.equal(t.totalPence, 10000);
});

test("percentage discount is applied before VAT", () => {
  const t = calculateTotals({ items: [line("1", "200")], vatEnabled: true, discountType: "percent", discountValue: "10" });
  assert.equal(t.discountPence, 2000);
  assert.equal(t.netPence, 18000);
  assert.equal(t.vatPence, 3600);
  assert.equal(t.totalPence, 21600);
});

test("fixed discount cannot exceed subtotal", () => {
  const t = calculateTotals({ items: [line("1", "50")], vatEnabled: false, discountType: "fixed", discountValue: "80" });
  assert.equal(t.discountPence, 5000);
  assert.equal(t.totalPence, 0);
});

test("mixed VAT rates with discount spread across bands", () => {
  const t = calculateTotals({
    items: [line("1", "1000", "20"), line("1", "500", "5"), line("1", "100", "0")],
    vatEnabled: true,
    discountType: "fixed",
    discountValue: "160",
  });
  assert.equal(t.subtotalPence, 160000);
  // discount 16000p split 10000/5000/1000 by weight
  const bands = Object.fromEntries(t.vatBands.map((b) => [b.rateBp, b]));
  assert.equal(bands[2000].netPence, 90000);
  assert.equal(bands[500].netPence, 45000);
  assert.equal(bands[0].netPence, 9000);
  assert.equal(t.vatPence, 18000 + 2250);
  assert.equal(t.totalPence, 144000 + 20250);
  const netSum = t.vatBands.reduce((a, b) => a + b.netPence, 0);
  assert.equal(netSum, t.netPence);
});

test("allocate always sums exactly", () => {
  for (const amount of [1, 7, 99, 1001]) {
    const parts = allocate(amount, [3, 3, 3]);
    assert.equal(parts.reduce((a, b) => a + b, 0), amount);
  }
});

test("invalid input lines count as zero, not NaN", () => {
  const t = calculateTotals({ items: [line("abc", "10"), line("2", "5")], vatEnabled: true, discountType: "none", discountValue: "" });
  assert.equal(t.subtotalPence, 1000);
  assert.ok(Number.isFinite(t.totalPence));
});

test("rounding of VAT to nearest penny", () => {
  // £0.99 at 20% = 19.8p -> 20p
  const t = calculateTotals({ items: [line("1", "0.99")], vatEnabled: true, discountType: "none", discountValue: "" });
  assert.equal(t.vatPence, 20);
  // £10.01 at 5% = 50.05p -> 50p
  const t2 = calculateTotals({ items: [line("1", "10.01", "5")], vatEnabled: true, discountType: "none", discountValue: "" });
  assert.equal(t2.vatPence, 50);
  // £10.10 at 5% = 50.5p -> 51p
  const t3 = calculateTotals({ items: [line("1", "10.10", "5")], vatEnabled: true, discountType: "none", discountValue: "" });
  assert.equal(t3.vatPence, 51);
});
