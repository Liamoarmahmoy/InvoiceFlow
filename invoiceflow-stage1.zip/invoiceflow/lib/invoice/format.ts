// UK formatting helpers: pounds sterling and dd/mm/yyyy style dates.

const gbp = new Intl.NumberFormat("en-GB", { style: "currency", currency: "GBP" });

export function formatPence(pence: number): string {
  return gbp.format(pence / 100);
}

export function formatRate(rateBp: number): string {
  const pct = rateBp / 100;
  return `${Number.isInteger(pct) ? pct : pct.toFixed(2)}%`;
}

/** "2026-11-09" -> "9 Nov 2026" (UK order). Returns "" for empty dates. */
export function formatDateUK(iso: string): string {
  if (!iso) return "";
  const [y, m, d] = iso.split("-").map(Number);
  if (!y || !m || !d) return "";
  const date = new Date(Date.UTC(y, m - 1, d));
  return new Intl.DateTimeFormat("en-GB", { day: "numeric", month: "short", year: "numeric", timeZone: "UTC" }).format(date);
}

/** Today's date as yyyy-mm-dd in the user's local time. */
export function todayISO(): string {
  const now = new Date();
  const local = new Date(now.getTime() - now.getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 10);
}

export function addDaysISO(iso: string, days: number): string {
  const [y, m, d] = iso.split("-").map(Number);
  const date = new Date(Date.UTC(y, (m || 1) - 1, d || 1));
  date.setUTCDate(date.getUTCDate() + days);
  return date.toISOString().slice(0, 10);
}

export function addressLines(a: { line1: string; line2: string; town: string; county: string; postcode: string; country: string }): string[] {
  return [a.line1, a.line2, a.town, a.county, a.postcode.toUpperCase(), a.country].map((s) => s.trim()).filter(Boolean);
}

/** Format a UK sort code as 12-34-56 if it has 6 digits. */
export function formatSortCode(v: string): string {
  const digits = v.replace(/\D/g, "");
  return digits.length === 6 ? `${digits.slice(0, 2)}-${digits.slice(2, 4)}-${digits.slice(4)}` : v;
}

/** Where a Companies House number is registered, from its prefix. */
export function registeredIn(companyNumber: string): string {
  const n = companyNumber.trim().toUpperCase();
  if (n.startsWith("SC")) return "Scotland";
  if (n.startsWith("NI")) return "Northern Ireland";
  return "England & Wales";
}

/** Footer line with legal registration details (shown on every template). */
export function companyFooter(b: { name: string; companyNumber: string; vatNumber: string }): string {
  return [
    b.name,
    b.companyNumber && `Registered in ${registeredIn(b.companyNumber)}, company no. ${b.companyNumber.trim().toUpperCase()}`,
    b.vatNumber && `VAT registration no. ${b.vatNumber.trim().toUpperCase()}`,
  ]
    .filter(Boolean)
    .join(" · ");
}
