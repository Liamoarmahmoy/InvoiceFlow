// Single source of truth for plans. Stage 4 will read the user's active plan
// from the database (written only by the Stripe webhook) and use LIMITS below
// to enforce access on the server — not just in the UI.

export type PlanId = "free" | "pro" | "business";

export const LIMITS: Record<PlanId, { invoicesPerMonth: number | null; templates: "classic" | "all"; customers: number | null }> = {
  free: { invoicesPerMonth: 3, templates: "classic", customers: 10 },
  pro: { invoicesPerMonth: null, templates: "all", customers: null },
  business: { invoicesPerMonth: null, templates: "all", customers: null },
};

export const PLANS: { id: PlanId; name: string; priceLabel: string; tagline: string; highlight?: boolean; features: string[] }[] = [
  {
    id: "free",
    name: "Free",
    priceLabel: "£0",
    tagline: "For getting started",
    features: ["Up to 3 invoices per month", "Classic invoice template", "PDF downloads", "Basic customer management"],
  },
  {
    id: "pro",
    name: "Pro",
    priceLabel: "£4.99",
    tagline: "For busy sole traders",
    highlight: true,
    features: [
      "Unlimited invoices",
      "All invoice templates",
      "Custom business branding",
      "Income dashboard and charts",
      "Unlimited saved customers",
      "Invoice duplication",
      "CSV exports",
    ],
  },
  {
    id: "business",
    name: "Business",
    priceLabel: "£9.99",
    tagline: "For growing businesses",
    features: ["Everything in Pro", "Recurring invoices", "Payment reminders", "Multiple business profiles", "Advanced reporting"],
  },
];

export const COMPARISON: { label: string; values: (string | boolean)[] }[] = [
  { label: "Invoices per month", values: ["3", "Unlimited", "Unlimited"] },
  { label: "Invoice templates", values: ["1", "All", "All"] },
  { label: "PDF download & print", values: [true, true, true] },
  { label: "VAT invoices", values: [true, true, true] },
  { label: "Saved customers", values: ["Up to 10", "Unlimited", "Unlimited"] },
  { label: "Custom branding & logo", values: [false, true, true] },
  { label: "Invoice duplication", values: [false, true, true] },
  { label: "Income dashboard & charts", values: [false, true, true] },
  { label: "CSV export", values: [false, true, true] },
  { label: "Recurring invoices", values: [false, false, true] },
  { label: "Payment reminders", values: [false, false, true] },
  { label: "Multiple business profiles", values: [false, false, true] },
  { label: "Advanced reporting", values: [false, false, true] },
];
